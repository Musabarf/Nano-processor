## ============================================================
## Basys3 XDC Constraint File - Nano_processor
## Board: Digilent Basys3 (xc7a35tcpg236-1)
## ============================================================

## SYSTEM CLOCK - 100 MHz onboard oscillator
set_property PACKAGE_PIN W5 [get_ports Clk]
set_property IOSTANDARD LVCMOS33 [get_ports Clk]
create_clock -add -name sys_clk_pin -period 10.00 -waveform {0 5} [get_ports Clk]

## RESET - BTNC
set_property PACKAGE_PIN U18 [get_ports Reset]
set_property IOSTANDARD LVCMOS33 [get_ports Reset]

## R7_out[3:0] on LD3..LD0
set_property PACKAGE_PIN V19 [get_ports {R7_out[3]}]
set_property PACKAGE_PIN U19 [get_ports {R7_out[2]}]
set_property PACKAGE_PIN E19 [get_ports {R7_out[1]}]
set_property PACKAGE_PIN U16 [get_ports {R7_out[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7_out[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7_out[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7_out[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7_out[0]}]

## OVERFLOW FLAG - LD15
set_property PACKAGE_PIN L1 [get_ports Overflow]
set_property IOSTANDARD LVCMOS33 [get_ports Overflow]

## ZERO FLAG - LD14
set_property PACKAGE_PIN P1 [get_ports Zero]
set_property IOSTANDARD LVCMOS33 [get_ports Zero]

## 7-SEGMENT CATHODES
set_property PACKAGE_PIN W7 [get_ports {seg[0]}]
set_property PACKAGE_PIN W6 [get_ports {seg[1]}]
set_property PACKAGE_PIN U8 [get_ports {seg[2]}]
set_property PACKAGE_PIN V8 [get_ports {seg[3]}]
set_property PACKAGE_PIN U5 [get_ports {seg[4]}]
set_property PACKAGE_PIN V5 [get_ports {seg[5]}]
set_property PACKAGE_PIN U7 [get_ports {seg[6]}]
set_property IOSTANDARD LVCMOS33 [get_ports {seg[*]}]

## 7-SEGMENT ANODES
set_property PACKAGE_PIN U2 [get_ports {an[0]}]
set_property PACKAGE_PIN U4 [get_ports {an[1]}]
set_property PACKAGE_PIN V4 [get_ports {an[2]}]
set_property PACKAGE_PIN W4 [get_ports {an[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {an[*]}]

## TIMING CONSTRAINTS
set_input_delay  -clock sys_clk_pin 0.0 [get_ports Reset]
set_output_delay -clock sys_clk_pin 0.0 [get_ports {R7_out[*]}]
set_output_delay -clock sys_clk_pin 0.0 [get_ports Overflow]
set_output_delay -clock sys_clk_pin 0.0 [get_ports Zero]
set_output_delay -clock sys_clk_pin 0.0 [get_ports {seg[*]}]
set_output_delay -clock sys_clk_pin 0.0 [get_ports {an[*]}]