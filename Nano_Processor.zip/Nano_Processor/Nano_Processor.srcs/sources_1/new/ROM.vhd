----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 02:42:22 PM
-- Design Name: 
-- Module Name: ROM - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ROM is
    Port ( address : in  STD_LOGIC_VECTOR(2 downto 0);
           data    : out STD_LOGIC_VECTOR(11 downto 0));
end ROM;

architecture Behavioral of ROM is
begin
    process(address)
    begin
        case address is
            -- MOVI R0, #5  => 100 000 0101 00
            when "000" => data <= "100000010100";
            -- MOVI R1, #3  => 100 001 0011 00
            when "001" => data <= "100001001100";
            -- ADD R2,R0,R1 => 001 010 000 001
            when "010" => data <= "001010000001";
            -- NEG R3, R1   => 011 011 001 000
            when "011" => data <= "011011001000";
            -- ADD R4,R2,R3 => 001 100 010 011
            when "100" => data <= "001100010011";
            -- JZR R0, 7   => 010 000 111 000
            when "101" => data <= "010000111000";
            -- MOVI R5, #1  => 100 101 0001 00
            when "110" => data <= "100101000100";
            -- ADD R6,R0,R1 => 001 110 000 001
            when "111" => data <= "001110000001";
            when others  => data <= "000000000000";
        end case;
    end process;
end Behavioral;
