----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 02:44:04 PM
-- Design Name: 
-- Module Name: Nano_processor - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

use IEEE.NUMERIC_STD.ALL;

entity Nano_processor is
    Port ( Clk      : in  STD_LOGIC;
           Reset    : in  STD_LOGIC;
           Result   : out STD_LOGIC_VECTOR(3 downto 0);
           Overflow : out STD_LOGIC;
           Zero     : out STD_LOGIC);
end Nano_processor;

architecture Structural of Nano_processor is

    -- Component declarations
    component Program_Counter
        port(D:in STD_LOGIC_VECTOR(2 downto 0); Load,Reset,Clk:in STD_LOGIC;
              Q:out STD_LOGIC_VECTOR(2 downto 0));
    end component;
    component pc_incrementer
        port(A:in STD_LOGIC_VECTOR(2 downto 0);
              Sum:out STD_LOGIC_VECTOR(2 downto 0); Cout:out STD_LOGIC);
    end component;
    component Mux_2_3bit
        port(I0,I1:in STD_LOGIC_VECTOR(2 downto 0); Sel:in STD_LOGIC;
              Y:out STD_LOGIC_VECTOR(2 downto 0));
    end component;
    component ROM
        port(address:in STD_LOGIC_VECTOR(2 downto 0);
              data:out STD_LOGIC_VECTOR(11 downto 0));
    end component;
    component Instruction_decoder
        port(Instruction:in STD_LOGIC_VECTOR(11 downto 0);
              Reg_En:out STD_LOGIC_VECTOR(7 downto 0);
              Mux_Sel_A,Mux_Sel_B,Jump_Addr:out STD_LOGIC_VECTOR(2 downto 0);
              Imm_Val:out STD_LOGIC_VECTOR(3 downto 0);
              Load_Imm,Add_Sub,Neg_En,Jump:out STD_LOGIC);
    end component;
    component Registers_Bank
        port(D:in STD_LOGIC_VECTOR(3 downto 0);
              Reg_En:in STD_LOGIC_VECTOR(7 downto 0);
              Clk,Reset:in STD_LOGIC;
              Q0,Q1,Q2,Q3,Q4,Q5,Q6,Q7:out STD_LOGIC_VECTOR(3 downto 0));
    end component;
    component Mux_8_4bit
        port(I0,I1,I2,I3,I4,I5,I6,I7:in STD_LOGIC_VECTOR(3 downto 0);
              Sel:in STD_LOGIC_VECTOR(2 downto 0);
              Y:out STD_LOGIC_VECTOR(3 downto 0));
    end component;
    component Mux_8_4bit_new
        port(I0,I1,I2,I3,I4,I5,I6,I7:in STD_LOGIC_VECTOR(3 downto 0);
              Sel:in STD_LOGIC_VECTOR(2 downto 0);
              Enable:in STD_LOGIC;
              Y:out STD_LOGIC_VECTOR(3 downto 0));
    end component;
    component Add_Sub_unit
        port(A,B:in STD_LOGIC_VECTOR(3 downto 0);
              Add_Sub:in STD_LOGIC;
              Result:out STD_LOGIC_VECTOR;
              Overflow:out STD_LOGIC;
              Zero:out STD_LOGIC);
    end component;
    component Mux_2_4bit
        port(I0,I1:in STD_LOGIC_VECTOR(3 downto 0); Sel:in STD_LOGIC;
              Y:out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    -- Internal signals
    signal PC_out, PC_inc, PC_in, Jump_Addr : STD_LOGIC_VECTOR(2 downto 0);
    signal instruction                      : STD_LOGIC_VECTOR(11 downto 0);
    signal Reg_En                           : STD_LOGIC_VECTOR(7 downto 0);
    signal Q0,Q1,Q2,Q3,Q4,Q5,Q6,Q7         : STD_LOGIC_VECTOR(3 downto 0);
    signal Mux_Sel_A, Mux_Sel_B             : STD_LOGIC_VECTOR(2 downto 0);
    signal ALU_A_raw, ALU_A, ALU_B          : STD_LOGIC_VECTOR(3 downto 0);
    signal ALU_Result, Imm_Val, Reg_In      : STD_LOGIC_VECTOR(3 downto 0);
    signal Overflow_sig                      : STD_LOGIC;
    signal Load_Imm, Add_Sub, Neg_En        : STD_LOGIC;
    signal Jump, Zero_sig, Cout_PC          : STD_LOGIC;
    signal Zero_check, Jump_en             : STD_LOGIC;

begin
    -- 1. Program Counter
    PC: Program_Counter port map(
        D=>PC_in, Load=>'1', Reset=>Reset, Clk=>Clk, Q=>PC_out);

    -- 2. PC Incrementer (PC + 1)
    INC: pc_incrementer port map(A=>PC_out, Sum=>PC_inc, Cout=>Cout_PC);

    -- 3. Next PC MUX: PC+1 or jump address
    Jump_en <= Jump and Zero_check;
    PCMUX: Mux_2_3bit port map(
        I0=>PC_inc, I1=>Jump_Addr, Sel=>Jump_en, Y=>PC_in);

    -- 4. ROM
    IROM: ROM port map(address=>PC_out, data=>instruction);

    -- 5. Instruction Decoder
    ID: Instruction_decoder port map(
        Instruction=>instruction, Reg_En=>Reg_En,
        Mux_Sel_A=>Mux_Sel_A, Mux_Sel_B=>Mux_Sel_B,
        Imm_Val=>Imm_Val, Load_Imm=>Load_Imm,
        Add_Sub=>Add_Sub, Neg_En=>Neg_En,
        Jump=>Jump, Jump_Addr=>Jump_Addr);

    -- 6. Register Bank
    RB: Registers_Bank port map(
        D=>Reg_In, Reg_En=>Reg_En, Clk=>Clk, Reset=>Reset,
        Q0=>Q0,Q1=>Q1,Q2=>Q2,Q3=>Q3,
        Q4=>Q4,Q5=>Q5,Q6=>Q6,Q7=>Q7);

    -- 7. MUX for ALU input A (Rs1)
    MUXA: Mux_8_4bit port map(
        I0=>Q0,I1=>Q1,I2=>Q2,I3=>Q3,
        I4=>Q4,I5=>Q5,I6=>Q6,I7=>Q7,
        Sel=>Mux_Sel_A, Y=>ALU_A_raw);

    -- 8. Force ALU_A = 0 for NEG operation
    ALU_A <= "0000" when Neg_En = '1' else ALU_A_raw;

    -- 9. MUX for ALU input B (Rs2, disabled=0000 for NEG)
    MUXB: Mux_8_4bit_new port map(
        I0=>Q0,I1=>Q1,I2=>Q2,I3=>Q3,
        I4=>Q4,I5=>Q5,I6=>Q6,I7=>Q7,
        Sel=>Mux_Sel_B, Enable=>'1', Y=>ALU_B);

    -- 10. ALU
    ALU: Add_Sub_unit port map(
        A=>ALU_A, B=>ALU_B, Add_Sub=>Add_Sub,
        Result=>ALU_Result, Overflow=>Overflow_sig,
        Zero=>Zero_sig);

    -- 11. Write-back MUX: ALU result or immediate
    WBMUX: Mux_2_4bit port map(
        I0=>ALU_Result, I1=>Imm_Val,
        Sel=>Load_Imm, Y=>Reg_In);

    -- 12. Zero check for JZR (checks Rs value on ALU_A_raw)
    Zero_check <= '1' when ALU_A_raw = "0000" else '0';

    -- Outputs
    Result   <= ALU_Result;
    Overflow <= Overflow_sig;
    Zero     <= Zero_sig;
end Structural;
