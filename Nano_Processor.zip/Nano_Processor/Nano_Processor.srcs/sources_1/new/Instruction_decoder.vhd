----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 02:43:08 PM
-- Design Name: 
-- Module Name: Instruction_decoder - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;
use IEEE.NUMERIC_STD.ALL;

entity Instruction_decoder is
    Port ( Instruction : in  STD_LOGIC_VECTOR(11 downto 0);
           Reg_En      : out STD_LOGIC_VECTOR(7 downto 0);
           Mux_Sel_A   : out STD_LOGIC_VECTOR(2 downto 0);
           Mux_Sel_B   : out STD_LOGIC_VECTOR(2 downto 0);
           Imm_Val     : out STD_LOGIC_VECTOR(3 downto 0);
           Load_Imm    : out STD_LOGIC;
           Add_Sub     : out STD_LOGIC;
           Neg_En      : out STD_LOGIC;
           Jump        : out STD_LOGIC;
           Jump_Addr   : out STD_LOGIC_VECTOR(2 downto 0));
end Instruction_decoder;

architecture Behavioral of Instruction_decoder is
    signal opcode : STD_LOGIC_VECTOR(2 downto 0);
    signal Rd     : STD_LOGIC_VECTOR(2 downto 0);
begin
    opcode <= Instruction(11 downto 9);
    Rd     <= Instruction(8  downto 6);

    process(Instruction, opcode, Rd)
        variable en : STD_LOGIC_VECTOR(7 downto 0);
    begin
        en := "00000000";
        if opcode /= "000" and opcode /= "010" then
            en(to_integer(unsigned(Rd))) := '1';
        end if;

        Reg_En    <= "00000000";
        Mux_Sel_A <= "000"; Mux_Sel_B <= "000";
        Imm_Val   <= "0000"; Load_Imm  <= '0';
        Add_Sub   <= '0';   Neg_En    <= '0';
        Jump      <= '0';   Jump_Addr <= "000";

        case opcode is
            when "001" =>  -- ADD Rd, Rs1, Rs2
                Reg_En    <= en;
                Mux_Sel_A <= Instruction(5 downto 3);
                Mux_Sel_B <= Instruction(2 downto 0);
                Add_Sub   <= '0';
            when "010" =>  -- JZR Rs, addr
                Mux_Sel_A <= Rd;
                Jump      <= '1';
                Jump_Addr <= Instruction(5 downto 3);
            when "011" =>  -- NEG Rd, Rs  (Rd = 0 - Rs)
                Reg_En    <= en;
                Mux_Sel_B <= Instruction(5 downto 3);
                Add_Sub   <= '1';
                Neg_En    <= '1';  -- force ALU_A = 0000
            when "100" =>  -- MOVI Rd, #imm
                Reg_En    <= en;
                Imm_Val   <= Instruction(5 downto 2);
                Load_Imm  <= '1';
            when others => null;  -- NOP
        end case;
    end process;
end Behavioral;
