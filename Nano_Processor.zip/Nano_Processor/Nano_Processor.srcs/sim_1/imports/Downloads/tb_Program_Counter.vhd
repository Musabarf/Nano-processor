----------------------------------------------------------------------------------
-- Testbench : tb_Program_Counter
-- DUT       : Program_Counter
-- Tests     : async reset, load on rising edge, hold when Load=0
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Program_Counter is
end tb_Program_Counter;

architecture Behavioral of tb_Program_Counter is

    component Program_Counter
        Port ( D     : in  STD_LOGIC_VECTOR(2 downto 0);
               Load  : in  STD_LOGIC;
               Reset : in  STD_LOGIC;
               Clk   : in  STD_LOGIC;
               Q     : out STD_LOGIC_VECTOR(2 downto 0));
    end component;

    signal D     : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal Load  : STD_LOGIC := '0';
    signal Reset : STD_LOGIC := '0';
    signal Clk   : STD_LOGIC := '0';
    signal Q     : STD_LOGIC_VECTOR(2 downto 0);

    constant CLK_PERIOD : time := 20 ns;

begin

    DUT: Program_Counter port map(D=>D, Load=>Load, Reset=>Reset, Clk=>Clk, Q=>Q);

    -- Clock generator
    Clk <= not Clk after CLK_PERIOD / 2;

    process
    begin
        -- Test 1: Async Reset
        Reset <= '1'; wait for 15 ns;
        assert Q = "000" report "FAIL: Reset did not clear Q" severity error;
        Reset <= '0'; wait for 5 ns;

        -- Test 2: Load D = 5 on rising edge
        D <= "101"; Load <= '1';
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q = "101" report "FAIL: Load 5" severity error;

        -- Test 3: Load D = 3
        D <= "011";
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q = "011" report "FAIL: Load 3" severity error;

        -- Test 4: Load = 0 → Q holds value
        D <= "111"; Load <= '0';
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q = "011" report "FAIL: Hold when Load=0" severity error;

        -- Test 5: Reset overrides load
        D <= "110"; Load <= '1'; Reset <= '1'; wait for 5 ns;
        assert Q = "000" report "FAIL: Reset priority" severity error;
        Reset <= '0';

        -- Test 6: Load D = 7 after reset
        D <= "111"; Load <= '1';
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q = "111" report "FAIL: Load 7 after reset" severity error;

        report "tb_Program_Counter: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
