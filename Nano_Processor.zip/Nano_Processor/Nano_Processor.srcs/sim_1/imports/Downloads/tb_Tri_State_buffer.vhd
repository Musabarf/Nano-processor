----------------------------------------------------------------------------------
-- Testbench : tb_Tri_State_buffer
-- DUT       : Tri_State_buffer (1-bit)
-- Tests     : enable=1 passes data, enable=0 outputs 'Z'
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Tri_State_buffer is
end tb_Tri_State_buffer;

architecture Behavioral of tb_Tri_State_buffer is

    component Tri_State_buffer
        Port ( data_in  : in  STD_LOGIC;
               enable   : in  STD_LOGIC;
               data_out : out STD_LOGIC);
    end component;

    signal data_in  : STD_LOGIC := '0';
    signal enable   : STD_LOGIC := '0';
    signal data_out : STD_LOGIC;

begin

    DUT: Tri_State_buffer port map(data_in=>data_in, enable=>enable, data_out=>data_out);

    process
    begin
        -- Test 1: enable=1, data_in=0 → data_out=0
        data_in <= '0'; enable <= '1'; wait for 20 ns;
        assert data_out = '0' report "FAIL: en=1, in=0" severity error;

        -- Test 2: enable=1, data_in=1 → data_out=1
        data_in <= '1'; enable <= '1'; wait for 20 ns;
        assert data_out = '1' report "FAIL: en=1, in=1" severity error;

        -- Test 3: enable=0, data_in=1 → data_out=Z
        data_in <= '1'; enable <= '0'; wait for 20 ns;
        assert data_out = 'Z' report "FAIL: en=0, should be Z" severity error;

        -- Test 4: enable=0, data_in=0 → data_out=Z
        data_in <= '0'; enable <= '0'; wait for 20 ns;
        assert data_out = 'Z' report "FAIL: en=0, in=0, should be Z" severity error;

        -- Test 5: Toggle enable rapidly
        data_in <= '1'; enable <= '1'; wait for 10 ns;
        assert data_out = '1' report "FAIL: rapid toggle on" severity error;
        enable <= '0'; wait for 10 ns;
        assert data_out = 'Z' report "FAIL: rapid toggle off" severity error;

        report "tb_Tri_State_buffer: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
