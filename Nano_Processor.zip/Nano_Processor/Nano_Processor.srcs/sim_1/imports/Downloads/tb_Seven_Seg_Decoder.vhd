----------------------------------------------------------------------------------
-- Testbench : tb_Seven_Seg_Decoder
-- DUT       : Seven_Seg_Decoder
-- Tests     : all 16 input values, active-low Basys3 encoding
--             seg = "gfedcba"  ('0'=ON, '1'=OFF)
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Seven_Seg_Decoder is
end tb_Seven_Seg_Decoder;

architecture Behavioral of tb_Seven_Seg_Decoder is

    component Seven_Seg_Decoder
        Port ( num : in  STD_LOGIC_VECTOR(3 downto 0);
               seg : out STD_LOGIC_VECTOR(6 downto 0));
    end component;

    signal num : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal seg : STD_LOGIC_VECTOR(6 downto 0);

begin

    DUT: Seven_Seg_Decoder port map(num=>num, seg=>seg);

    process
    begin
        num <= "0000"; wait for 20 ns;  -- 0
        assert seg = "1000000" report "FAIL: digit 0" severity error;

        num <= "0001"; wait for 20 ns;  -- 1
        assert seg = "1111001" report "FAIL: digit 1" severity error;

        num <= "0010"; wait for 20 ns;  -- 2
        assert seg = "0100100" report "FAIL: digit 2" severity error;

        num <= "0011"; wait for 20 ns;  -- 3
        assert seg = "0110000" report "FAIL: digit 3" severity error;

        num <= "0100"; wait for 20 ns;  -- 4
        assert seg = "0011001" report "FAIL: digit 4" severity error;

        num <= "0101"; wait for 20 ns;  -- 5
        assert seg = "0010010" report "FAIL: digit 5" severity error;

        num <= "0110"; wait for 20 ns;  -- 6
        assert seg = "0000010" report "FAIL: digit 6" severity error;

        num <= "0111"; wait for 20 ns;  -- 7
        assert seg = "1111000" report "FAIL: digit 7" severity error;

        num <= "1000"; wait for 20 ns;  -- 8
        assert seg = "0000000" report "FAIL: digit 8" severity error;

        num <= "1001"; wait for 20 ns;  -- 9
        assert seg = "0010000" report "FAIL: digit 9" severity error;

        -- Values 10-15 should produce "1111111" (blank) per your decoder
        num <= "1010"; wait for 20 ns;
        assert seg = "1111111" report "FAIL: digit A (blank)" severity error;

        num <= "1011"; wait for 20 ns;
        assert seg = "1111111" report "FAIL: digit B (blank)" severity error;

        num <= "1100"; wait for 20 ns;
        assert seg = "1111111" report "FAIL: digit C (blank)" severity error;

        num <= "1101"; wait for 20 ns;
        assert seg = "1111111" report "FAIL: digit D (blank)" severity error;

        num <= "1110"; wait for 20 ns;
        assert seg = "1111111" report "FAIL: digit E (blank)" severity error;

        num <= "1111"; wait for 20 ns;
        assert seg = "1111111" report "FAIL: digit F (blank)" severity error;

        report "tb_Seven_Seg_Decoder: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
