----------------------------------------------------------------------------------
-- Testbench : tb_three_bit_adder
-- DUT       : three_bit_adder
-- Tests     : all carry-in combinations, overflow, max values
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_three_bit_adder is
end tb_three_bit_adder;

architecture Behavioral of tb_three_bit_adder is

    component three_bit_adder
        Port ( A    : in  STD_LOGIC_VECTOR(2 downto 0);
               B    : in  STD_LOGIC_VECTOR(2 downto 0);
               Cin  : in  STD_LOGIC;
               Sum  : out STD_LOGIC_VECTOR(2 downto 0);
               Cout : out STD_LOGIC);
    end component;

    signal A, B  : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal Cin   : STD_LOGIC := '0';
    signal Sum   : STD_LOGIC_VECTOR(2 downto 0);
    signal Cout  : STD_LOGIC;

begin

    DUT: three_bit_adder port map(A=>A, B=>B, Cin=>Cin, Sum=>Sum, Cout=>Cout);

    process
    begin
        -- Test 1: 0 + 0 + 0 = 0, Cout=0
        A <= "000"; B <= "000"; Cin <= '0'; wait for 20 ns;
        assert Sum = "000" and Cout = '0'
            report "FAIL: 0+0+0" severity error;

        -- Test 2: 1 + 1 + 0 = 2, Cout=0
        A <= "001"; B <= "001"; Cin <= '0'; wait for 20 ns;
        assert Sum = "010" and Cout = '0'
            report "FAIL: 1+1+0" severity error;

        -- Test 3: 3 + 4 + 0 = 7, Cout=0
        A <= "011"; B <= "100"; Cin <= '0'; wait for 20 ns;
        assert Sum = "111" and Cout = '0'
            report "FAIL: 3+4+0" severity error;

        -- Test 4: 5 + 3 + 0 = 8 -> Sum=0, Cout=1
        A <= "101"; B <= "011"; Cin <= '0'; wait for 20 ns;
        assert Sum = "000" and Cout = '1'
            report "FAIL: 5+3+0 overflow" severity error;

        -- Test 5: 7 + 7 + 1 = 15 -> Sum=7, Cout=1
        A <= "111"; B <= "111"; Cin <= '1'; wait for 20 ns;
        assert Sum = "111" and Cout = '1'
            report "FAIL: 7+7+1" severity error;

        -- Test 6: Cin propagation: 3 + 3 + 1 = 7
        A <= "011"; B <= "011"; Cin <= '1'; wait for 20 ns;
        assert Sum = "111" and Cout = '0'
            report "FAIL: 3+3+1" severity error;

        -- Test 7: Incrementer use-case: 6 + 1 + 0 = 7
        A <= "110"; B <= "001"; Cin <= '0'; wait for 20 ns;
        assert Sum = "111" and Cout = '0'
            report "FAIL: 6+1+0" severity error;

        -- Test 8: Wrap-around: 7 + 1 + 0 = 0 carry
        A <= "111"; B <= "001"; Cin <= '0'; wait for 20 ns;
        assert Sum = "000" and Cout = '1'
            report "FAIL: 7+1 wrap" severity error;

        report "tb_three_bit_adder: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
