----------------------------------------------------------------------------------
-- Testbench : tb_pc_incrementer
-- DUT       : pc_incrementer
-- Tests     : +1 on all 3-bit values including wrap-around
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_pc_incrementer is
end tb_pc_incrementer;

architecture Behavioral of tb_pc_incrementer is

    component pc_incrementer
        Port ( A    : in  STD_LOGIC_VECTOR(2 downto 0);
               Sum  : out STD_LOGIC_VECTOR(2 downto 0);
               Cout : out STD_LOGIC);
    end component;

    signal A    : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal Sum  : STD_LOGIC_VECTOR(2 downto 0);
    signal Cout : STD_LOGIC;

begin

    DUT: pc_incrementer port map(A=>A, Sum=>Sum, Cout=>Cout);

    process
    begin
        -- Test all 8 PC values
        A <= "000"; wait for 20 ns;   -- 0+1=1, Cout=0
        assert Sum = "001" and Cout = '0' report "FAIL: PC=0" severity error;

        A <= "001"; wait for 20 ns;   -- 1+1=2
        assert Sum = "010" and Cout = '0' report "FAIL: PC=1" severity error;

        A <= "010"; wait for 20 ns;   -- 2+1=3
        assert Sum = "011" and Cout = '0' report "FAIL: PC=2" severity error;

        A <= "011"; wait for 20 ns;   -- 3+1=4
        assert Sum = "100" and Cout = '0' report "FAIL: PC=3" severity error;

        A <= "100"; wait for 20 ns;   -- 4+1=5
        assert Sum = "101" and Cout = '0' report "FAIL: PC=4" severity error;

        A <= "101"; wait for 20 ns;   -- 5+1=6
        assert Sum = "110" and Cout = '0' report "FAIL: PC=5" severity error;

        A <= "110"; wait for 20 ns;   -- 6+1=7
        assert Sum = "111" and Cout = '0' report "FAIL: PC=6" severity error;

        A <= "111"; wait for 20 ns;   -- 7+1=8 → Sum=0, Cout=1 (wrap)
        assert Sum = "000" and Cout = '1' report "FAIL: PC=7 wrap" severity error;

        report "tb_pc_incrementer: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
