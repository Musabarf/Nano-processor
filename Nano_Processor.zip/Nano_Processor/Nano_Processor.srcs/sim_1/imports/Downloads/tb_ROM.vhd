----------------------------------------------------------------------------------
-- Testbench : tb_ROM
-- DUT       : ROM
-- Tests     : all 8 addresses return exactly the expected 12-bit instruction
--
-- ROM program (from source):
--   addr 0: MOVI R0,#5  = "100000010100"
--   addr 1: MOVI R1,#3  = "100001001100"
--   addr 2: ADD R2,R0,R1= "001010000001"
--   addr 3: NEG R3,R1   = "011011001000"
--   addr 4: ADD R4,R2,R3= "001100010011"
--   addr 5: JZR R0,7    = "010000111000"
--   addr 6: MOVI R5,#1  = "100101000100"
--   addr 7: ADD R6,R0,R1= "001110000001"
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_ROM is
end tb_ROM;

architecture Behavioral of tb_ROM is

    component ROM
        Port ( address : in  STD_LOGIC_VECTOR(2 downto 0);
               data    : out STD_LOGIC_VECTOR(11 downto 0));
    end component;

    signal address : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal data    : STD_LOGIC_VECTOR(11 downto 0);

begin

    DUT: ROM port map(address=>address, data=>data);

    process
    begin
        address <= "000"; wait for 20 ns;
        assert data = "100000010100"
            report "FAIL: addr 0 (MOVI R0,#5)" severity error;

        address <= "001"; wait for 20 ns;
        assert data = "100001001100"
            report "FAIL: addr 1 (MOVI R1,#3)" severity error;

        address <= "010"; wait for 20 ns;
        assert data = "001010000001"
            report "FAIL: addr 2 (ADD R2,R0,R1)" severity error;

        address <= "011"; wait for 20 ns;
        assert data = "011011001000"
            report "FAIL: addr 3 (NEG R3,R1)" severity error;

        address <= "100"; wait for 20 ns;
        assert data = "001100010011"
            report "FAIL: addr 4 (ADD R4,R2,R3)" severity error;

        address <= "101"; wait for 20 ns;
        assert data = "010000111000"
            report "FAIL: addr 5 (JZR R0,7)" severity error;

        address <= "110"; wait for 20 ns;
        assert data = "100101000100"
            report "FAIL: addr 6 (MOVI R5,#1)" severity error;

        address <= "111"; wait for 20 ns;
        assert data = "001110000001"
            report "FAIL: addr 7 (ADD R6,R0,R1)" severity error;

        report "tb_ROM: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
