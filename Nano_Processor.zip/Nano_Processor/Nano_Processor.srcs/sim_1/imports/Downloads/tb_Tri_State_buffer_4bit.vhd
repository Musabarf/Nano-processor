----------------------------------------------------------------------------------
-- Testbench : tb_Tri_State_buffer_4bit
-- DUT       : Tri_State_buffer_4bit
-- Tests     : enable=1 passes bus, enable=0 outputs "ZZZZ"
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Tri_State_buffer_4bit is
end tb_Tri_State_buffer_4bit;

architecture Behavioral of tb_Tri_State_buffer_4bit is

    component Tri_State_buffer_4bit
        Port ( data_in  : in  STD_LOGIC_VECTOR(3 downto 0);
               enable   : in  STD_LOGIC;
               data_out : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    signal data_in  : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal enable   : STD_LOGIC := '0';
    signal data_out : STD_LOGIC_VECTOR(3 downto 0);

begin

    DUT: Tri_State_buffer_4bit port map(
        data_in=>data_in, enable=>enable, data_out=>data_out);

    process
    begin
        -- Test 1: enable=1, data=5 → output=5
        data_in <= "0101"; enable <= '1'; wait for 20 ns;
        assert data_out = "0101" report "FAIL: en=1, data=5" severity error;

        -- Test 2: enable=1, data=A → output=A
        data_in <= "1010"; enable <= '1'; wait for 20 ns;
        assert data_out = "1010" report "FAIL: en=1, data=A" severity error;

        -- Test 3: enable=1, data=F
        data_in <= "1111"; enable <= '1'; wait for 20 ns;
        assert data_out = "1111" report "FAIL: en=1, data=F" severity error;

        -- Test 4: enable=0 → high-impedance
        data_in <= "1111"; enable <= '0'; wait for 20 ns;
        assert data_out = "ZZZZ" report "FAIL: en=0, should be ZZZZ" severity error;

        -- Test 5: enable=0, data=0 → still Z
        data_in <= "0000"; enable <= '0'; wait for 20 ns;
        assert data_out = "ZZZZ" report "FAIL: en=0, data=0, should be ZZZZ" severity error;

        -- Test 6: Re-enable → output passes through
        data_in <= "0110"; enable <= '1'; wait for 20 ns;
        assert data_out = "0110" report "FAIL: re-enable" severity error;

        report "tb_Tri_State_buffer_4bit: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
