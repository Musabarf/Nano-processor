----------------------------------------------------------------------------------
-- Testbench : tb_Add_Sub_unit
-- DUT       : Add_Sub_unit
-- Tests     : addition, subtraction, overflow, zero flag
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_Add_Sub_unit is
end tb_Add_Sub_unit;

architecture Behavioral of tb_Add_Sub_unit is

    component Add_Sub_unit
        Port ( A        : in  STD_LOGIC_VECTOR(3 downto 0);
               B        : in  STD_LOGIC_VECTOR(3 downto 0);
               Add_Sub  : in  STD_LOGIC;
               Result   : out STD_LOGIC_VECTOR(3 downto 0);
               Overflow : out STD_LOGIC;
               Zero     : out STD_LOGIC);
    end component;

    signal A, B    : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal Add_Sub : STD_LOGIC := '0';
    signal Result  : STD_LOGIC_VECTOR(3 downto 0);
    signal Overflow: STD_LOGIC;
    signal Zero    : STD_LOGIC;

begin

    DUT: Add_Sub_unit port map(A=>A, B=>B, Add_Sub=>Add_Sub,
                                Result=>Result, Overflow=>Overflow, Zero=>Zero);

    process
    begin
        -- ── ADD tests (Add_Sub = '0') ─────────────────────────────

        -- Test 1: 5 + 3 = 8, Overflow=0, Zero=0
        A <= "0101"; B <= "0011"; Add_Sub <= '0'; wait for 20 ns;
        assert Result = "1000" and Overflow = '0' and Zero = '0'
            report "FAIL: ADD 5+3" severity error;

        -- Test 2: 0 + 0 = 0, Zero=1
        A <= "0000"; B <= "0000"; Add_Sub <= '0'; wait for 20 ns;
        assert Result = "0000" and Zero = '1'
            report "FAIL: ADD 0+0 zero flag" severity error;

        -- Test 3: 15 + 1 = 16 -> Overflow=1, Result=0
        A <= "1111"; B <= "0001"; Add_Sub <= '0'; wait for 20 ns;
        assert Result = "0000" and Overflow = '1'
            report "FAIL: ADD 15+1 overflow" severity error;

        -- Test 4: 7 + 7 = 14, Overflow=0
        A <= "0111"; B <= "0111"; Add_Sub <= '0'; wait for 20 ns;
        assert Result = "1110" and Overflow = '0' and Zero = '0'
            report "FAIL: ADD 7+7" severity error;

        -- ── SUB tests (Add_Sub = '1') ─────────────────────────────

        -- Test 5: 5 - 3 = 2, Overflow=0, Zero=0
        A <= "0101"; B <= "0011"; Add_Sub <= '1'; wait for 20 ns;
        assert Result = "0010" and Overflow = '0' and Zero = '0'
            report "FAIL: SUB 5-3" severity error;

        -- Test 6: 4 - 4 = 0, Zero=1
        A <= "0100"; B <= "0100"; Add_Sub <= '1'; wait for 20 ns;
        assert Result = "0000" and Zero = '1'
            report "FAIL: SUB 4-4 zero flag" severity error;

        -- Test 7: NEG use-case: 0 - 3 (two's complement of 3 = 13 = 0xD)
        A <= "0000"; B <= "0011"; Add_Sub <= '1'; wait for 20 ns;
        assert Result = "1101"
            report "FAIL: SUB 0-3 (NEG)" severity error;

        -- Test 8: 1 - 1 = 0, Zero=1
        A <= "0001"; B <= "0001"; Add_Sub <= '1'; wait for 20 ns;
        assert Result = "0000" and Zero = '1'
            report "FAIL: SUB 1-1" severity error;

        report "tb_Add_Sub_unit: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
