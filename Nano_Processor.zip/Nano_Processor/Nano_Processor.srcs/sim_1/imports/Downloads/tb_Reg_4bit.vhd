----------------------------------------------------------------------------------
-- Testbench : tb_Reg_4bit
-- DUT       : Reg_4bit
-- Tests     : async reset, load on rising edge, hold when Load=0
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Reg_4bit is
end tb_Reg_4bit;

architecture Behavioral of tb_Reg_4bit is

    component Reg_4bit
        Port ( D     : in  STD_LOGIC_VECTOR(3 downto 0);
               Load  : in  STD_LOGIC;
               Reset : in  STD_LOGIC;
               Clk   : in  STD_LOGIC;
               Q     : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    signal D     : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal Load  : STD_LOGIC := '0';
    signal Reset : STD_LOGIC := '0';
    signal Clk   : STD_LOGIC := '0';
    signal Q     : STD_LOGIC_VECTOR(3 downto 0);

    constant CLK_PERIOD : time := 20 ns;

begin

    DUT: Reg_4bit port map(D=>D, Load=>Load, Reset=>Reset, Clk=>Clk, Q=>Q);

    Clk <= not Clk after CLK_PERIOD / 2;

    process
    begin
        -- Test 1: Async Reset → Q = 0
        D <= "1111"; Load <= '1'; Reset <= '1'; wait for 15 ns;
        assert Q = "0000" report "FAIL: Reset" severity error;
        Reset <= '0'; wait for 5 ns;

        -- Test 2: Load 5 (0101)
        D <= "0101"; Load <= '1';
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q = "0101" report "FAIL: Load 5" severity error;

        -- Test 3: Load 10 (1010)
        D <= "1010";
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q = "1010" report "FAIL: Load 10" severity error;

        -- Test 4: Load = 0 → holds 10
        D <= "0000"; Load <= '0';
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q = "1010" report "FAIL: Hold" severity error;

        -- Test 5: Load 15 (1111)
        D <= "1111"; Load <= '1';
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q = "1111" report "FAIL: Load 15" severity error;

        -- Test 6: Reset mid-operation
        Reset <= '1'; wait for 5 ns;
        assert Q = "0000" report "FAIL: Mid-operation reset" severity error;
        Reset <= '0';

        report "tb_Reg_4bit: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
