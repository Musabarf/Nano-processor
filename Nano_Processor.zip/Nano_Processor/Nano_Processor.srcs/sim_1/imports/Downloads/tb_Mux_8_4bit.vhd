----------------------------------------------------------------------------------
-- Testbench : tb_Mux_8_4bit
-- DUT       : Mux_8_4bit
-- Tests     : each of the 8 select lines picks the correct input
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Mux_8_4bit is
end tb_Mux_8_4bit;

architecture Behavioral of tb_Mux_8_4bit is

    component Mux_8_4bit
        Port ( I0, I1, I2, I3,
               I4, I5, I6, I7 : in  STD_LOGIC_VECTOR(3 downto 0);
               Sel             : in  STD_LOGIC_VECTOR(2 downto 0);
               Y               : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    signal I0 : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal I1 : STD_LOGIC_VECTOR(3 downto 0) := "0001";
    signal I2 : STD_LOGIC_VECTOR(3 downto 0) := "0010";
    signal I3 : STD_LOGIC_VECTOR(3 downto 0) := "0011";
    signal I4 : STD_LOGIC_VECTOR(3 downto 0) := "0100";
    signal I5 : STD_LOGIC_VECTOR(3 downto 0) := "0101";
    signal I6 : STD_LOGIC_VECTOR(3 downto 0) := "0110";
    signal I7 : STD_LOGIC_VECTOR(3 downto 0) := "0111";
    signal Sel : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal Y   : STD_LOGIC_VECTOR(3 downto 0);

begin

    DUT: Mux_8_4bit port map(
        I0=>I0,I1=>I1,I2=>I2,I3=>I3,
        I4=>I4,I5=>I5,I6=>I6,I7=>I7,
        Sel=>Sel, Y=>Y);

    process
    begin
        -- Each input is loaded with its index value for easy verification
        Sel <= "000"; wait for 20 ns;
        assert Y = "0000" report "FAIL: Sel=0" severity error;

        Sel <= "001"; wait for 20 ns;
        assert Y = "0001" report "FAIL: Sel=1" severity error;

        Sel <= "010"; wait for 20 ns;
        assert Y = "0010" report "FAIL: Sel=2" severity error;

        Sel <= "011"; wait for 20 ns;
        assert Y = "0011" report "FAIL: Sel=3" severity error;

        Sel <= "100"; wait for 20 ns;
        assert Y = "0100" report "FAIL: Sel=4" severity error;

        Sel <= "101"; wait for 20 ns;
        assert Y = "0101" report "FAIL: Sel=5" severity error;

        Sel <= "110"; wait for 20 ns;
        assert Y = "0110" report "FAIL: Sel=6" severity error;

        Sel <= "111"; wait for 20 ns;
        assert Y = "0111" report "FAIL: Sel=7" severity error;

        -- Test with non-trivial values on I3 and I5
        I3 <= "1011"; I5 <= "1101";
        Sel <= "011"; wait for 20 ns;
        assert Y = "1011" report "FAIL: I3 changed" severity error;

        Sel <= "101"; wait for 20 ns;
        assert Y = "1101" report "FAIL: I5 changed" severity error;

        report "tb_Mux_8_4bit: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
