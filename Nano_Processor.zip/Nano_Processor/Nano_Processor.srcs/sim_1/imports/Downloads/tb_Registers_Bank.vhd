----------------------------------------------------------------------------------
-- Testbench : tb_Registers_Bank
-- DUT       : Registers_Bank (8 x Reg_4bit)
-- Tests     : write to each register via Reg_En, async reset, no-write hold
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Registers_Bank is
end tb_Registers_Bank;

architecture Behavioral of tb_Registers_Bank is

    component Registers_Bank
        Port ( D       : in  STD_LOGIC_VECTOR(3 downto 0);
               Reg_En  : in  STD_LOGIC_VECTOR(7 downto 0);
               Clk     : in  STD_LOGIC;
               Reset   : in  STD_LOGIC;
               Q0, Q1, Q2, Q3,
               Q4, Q5, Q6, Q7 : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    signal D      : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal Reg_En : STD_LOGIC_VECTOR(7 downto 0) := "00000000";
    signal Clk    : STD_LOGIC := '0';
    signal Reset  : STD_LOGIC := '0';
    signal Q0,Q1,Q2,Q3,Q4,Q5,Q6,Q7 : STD_LOGIC_VECTOR(3 downto 0);

    constant CLK_PERIOD : time := 20 ns;

begin

    DUT: Registers_Bank port map(
        D=>D, Reg_En=>Reg_En, Clk=>Clk, Reset=>Reset,
        Q0=>Q0,Q1=>Q1,Q2=>Q2,Q3=>Q3,
        Q4=>Q4,Q5=>Q5,Q6=>Q6,Q7=>Q7);

    Clk <= not Clk after CLK_PERIOD / 2;

    process
    begin
        -- Test 1: Async Reset → all Q = 0
        Reset <= '1'; wait for 15 ns;
        assert Q0="0000" and Q1="0000" and Q2="0000" and Q3="0000" and
               Q4="0000" and Q5="0000" and Q6="0000" and Q7="0000"
            report "FAIL: Reset" severity error;
        Reset <= '0'; wait for 5 ns;

        -- Test 2: Write 5 to R1 (Reg_En bit 1)
        D <= "0101"; Reg_En <= "00000010";
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q1 = "0101" report "FAIL: Write R1=5" severity error;
        assert Q0 = "0000" report "FAIL: R0 should stay 0 after R1 write" severity error;

        -- Test 3: Write 3 to R2 (Reg_En bit 2)
        D <= "0011"; Reg_En <= "00000100";
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q2 = "0011" report "FAIL: Write R2=3" severity error;
        assert Q1 = "0101" report "FAIL: R1 should hold 5" severity error;

        -- Test 4: Write 8 to R7 (Reg_En bit 7)
        D <= "1000"; Reg_En <= "10000000";
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q7 = "1000" report "FAIL: Write R7=8" severity error;

        -- Test 5: No enable → all registers hold values
        D <= "1111"; Reg_En <= "00000000";
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q1 = "0101" report "FAIL: R1 hold" severity error;
        assert Q2 = "0011" report "FAIL: R2 hold" severity error;
        assert Q7 = "1000" report "FAIL: R7 hold" severity error;

        -- Test 6: Write 15 to R4
        D <= "1111"; Reg_En <= "00010000";
        wait until rising_edge(Clk); wait for 5 ns;
        assert Q4 = "1111" report "FAIL: Write R4=F" severity error;

        -- Test 7: Reset clears all
        Reset <= '1'; wait for 5 ns;
        assert Q1="0000" and Q2="0000" and Q4="0000" and Q7="0000"
            report "FAIL: Second reset" severity error;
        Reset <= '0';

        report "tb_Registers_Bank: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
