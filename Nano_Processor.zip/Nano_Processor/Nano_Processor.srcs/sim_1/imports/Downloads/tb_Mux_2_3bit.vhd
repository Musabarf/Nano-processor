----------------------------------------------------------------------------------
-- Testbench : tb_Mux_2_3bit
-- DUT       : Mux_2_3bit
-- Tests     : Sel=0 selects I0, Sel=1 selects I1, all combinations
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Mux_2_3bit is
end tb_Mux_2_3bit;

architecture Behavioral of tb_Mux_2_3bit is

    component Mux_2_3bit
        Port ( I0  : in  STD_LOGIC_VECTOR(2 downto 0);
               I1  : in  STD_LOGIC_VECTOR(2 downto 0);
               Sel : in  STD_LOGIC;
               Y   : out STD_LOGIC_VECTOR(2 downto 0));
    end component;

    signal I0, I1 : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal Sel    : STD_LOGIC := '0';
    signal Y      : STD_LOGIC_VECTOR(2 downto 0);

begin

    DUT: Mux_2_3bit port map(I0=>I0, I1=>I1, Sel=>Sel, Y=>Y);

    process
    begin
        -- Test 1: Sel=0 → Y = I0
        I0 <= "101"; I1 <= "010"; Sel <= '0'; wait for 20 ns;
        assert Y = "101" report "FAIL: Sel=0 should select I0" severity error;

        -- Test 2: Sel=1 → Y = I1
        Sel <= '1'; wait for 20 ns;
        assert Y = "010" report "FAIL: Sel=1 should select I1" severity error;

        -- Test 3: Change I0, Sel=0
        I0 <= "111"; Sel <= '0'; wait for 20 ns;
        assert Y = "111" report "FAIL: I0=7, Sel=0" severity error;

        -- Test 4: Change I1, Sel=1
        I1 <= "110"; Sel <= '1'; wait for 20 ns;
        assert Y = "110" report "FAIL: I1=6, Sel=1" severity error;

        -- Test 5: Both same value
        I0 <= "011"; I1 <= "011"; Sel <= '0'; wait for 20 ns;
        assert Y = "011" report "FAIL: Both 3, Sel=0" severity error;

        Sel <= '1'; wait for 20 ns;
        assert Y = "011" report "FAIL: Both 3, Sel=1" severity error;

        -- Test 6: PC use-case: I0=PC+1="100", I1=jump="001"
        I0 <= "100"; I1 <= "001";
        Sel <= '0'; wait for 20 ns;
        assert Y = "100" report "FAIL: PC mux no-jump" severity error;
        Sel <= '1'; wait for 20 ns;
        assert Y = "001" report "FAIL: PC mux jump" severity error;

        report "tb_Mux_2_3bit: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
