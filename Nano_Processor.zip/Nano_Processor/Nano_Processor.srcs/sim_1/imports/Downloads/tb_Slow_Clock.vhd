----------------------------------------------------------------------------------
-- Testbench : tb_Slow_Clock
-- DUT       : Slow_Clock
--
-- IMPORTANT: Before simulating, temporarily change MAX_COUNT in Slow_Clock
-- from 50_000_000 to a small value, e.g. 4, so the simulation finishes fast:
--
--     constant MAX_COUNT : integer := 4;   -- for simulation only
--
-- This testbench verifies:
--   1. Reset holds Clk_slow = '0'
--   2. Clk_slow stays '0' for MAX_COUNT cycles then toggles
--   3. Clk_slow toggles again after another MAX_COUNT cycles
--   4. Re-asserting Reset immediately clears Clk_slow
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Slow_Clock is
end tb_Slow_Clock;

architecture Behavioral of tb_Slow_Clock is

    component Slow_Clock
        Port ( Clk_100MHz : in  STD_LOGIC;
               Reset      : in  STD_LOGIC;
               Clk_slow   : out STD_LOGIC);
    end component;

    signal Clk_100MHz : STD_LOGIC := '0';
    signal Reset      : STD_LOGIC := '0';
    signal Clk_slow   : STD_LOGIC;

    -- Match whatever MAX_COUNT you set in the DUT for simulation
    -- If DUT has MAX_COUNT=4, one half-period = 4 * 10ns = 40ns
    constant CLK_PERIOD    : time := 10 ns;   -- 100 MHz
    constant MAX_CNT       : integer := 4;    -- must match DUT's MAX_COUNT
    constant HALF_SLOW     : time := MAX_CNT * CLK_PERIOD;

begin

    DUT: Slow_Clock port map(
        Clk_100MHz => Clk_100MHz,
        Reset      => Reset,
        Clk_slow   => Clk_slow);

    -- 100 MHz clock
    Clk_100MHz <= not Clk_100MHz after CLK_PERIOD / 2;

    process
    begin
        -- Test 1: Reset holds Clk_slow = 0
        Reset <= '1'; wait for 5 * CLK_PERIOD;
        assert Clk_slow = '0' report "FAIL: Reset should hold Clk_slow=0" severity error;
        Reset <= '0';

        -- Test 2: Clk_slow starts low; after MAX_COUNT rising edges it goes high
        assert Clk_slow = '0' report "FAIL: Should start at 0 after reset" severity error;
        wait for HALF_SLOW + CLK_PERIOD;   -- one half-period + margin
        assert Clk_slow = '1' report "FAIL: Clk_slow should toggle to 1" severity error;

        -- Test 3: Another MAX_COUNT cycles → toggles back to 0
        wait for HALF_SLOW;
        assert Clk_slow = '0' report "FAIL: Clk_slow should toggle back to 0" severity error;

        -- Test 4: One more toggle
        wait for HALF_SLOW;
        assert Clk_slow = '1' report "FAIL: Clk_slow should toggle to 1 again" severity error;

        -- Test 5: Reset mid-operation clears immediately
        Reset <= '1'; wait for CLK_PERIOD;
        assert Clk_slow = '0' report "FAIL: Mid-run reset" severity error;
        Reset <= '0';

        -- Test 6: Resumes toggling from 0 after reset
        wait for HALF_SLOW + CLK_PERIOD;
        assert Clk_slow = '1' report "FAIL: Clk_slow should resume toggling after reset" severity error;

        report "tb_Slow_Clock: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
