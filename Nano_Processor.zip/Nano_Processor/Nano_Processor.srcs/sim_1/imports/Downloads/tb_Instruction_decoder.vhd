----------------------------------------------------------------------------------
-- Testbench : tb_Instruction_decoder
-- DUT       : Instruction_decoder
--
-- Instruction format:
--   bits [11:9] = opcode  bits [8:6] = Rd  bits [5:3] = Rs1  bits [2:0] = Rs2
--
-- Opcodes:
--   001 = ADD    Reg_En[Rd]=1, Mux_Sel_A=Rs1, Mux_Sel_B=Rs2, Add_Sub=0
--   010 = JZR    Mux_Sel_A=Rd, Jump=1, Jump_Addr=Rs1
--   011 = NEG    Reg_En[Rd]=1, Mux_Sel_B=Rs1, Add_Sub=1, Neg_En=1
--   100 = MOVI   Reg_En[Rd]=1, Imm_Val=bits[5:2], Load_Imm=1
--   000 = NOP    all outputs default/zero
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Instruction_decoder is
end tb_Instruction_decoder;

architecture Behavioral of tb_Instruction_decoder is

    component Instruction_decoder
        Port ( Instruction : in  STD_LOGIC_VECTOR(11 downto 0);
               Reg_En      : out STD_LOGIC_VECTOR(7 downto 0);
               Mux_Sel_A   : out STD_LOGIC_VECTOR(2 downto 0);
               Mux_Sel_B   : out STD_LOGIC_VECTOR(2 downto 0);
               Imm_Val     : out STD_LOGIC_VECTOR(3 downto 0);
               Load_Imm    : out STD_LOGIC;
               Add_Sub     : out STD_LOGIC;
               Neg_En      : out STD_LOGIC;
               Jump        : out STD_LOGIC;
               Jump_Addr   : out STD_LOGIC_VECTOR(2 downto 0));
    end component;

    signal Instruction : STD_LOGIC_VECTOR(11 downto 0) := "000000000000";
    signal Reg_En      : STD_LOGIC_VECTOR(7 downto 0);
    signal Mux_Sel_A   : STD_LOGIC_VECTOR(2 downto 0);
    signal Mux_Sel_B   : STD_LOGIC_VECTOR(2 downto 0);
    signal Imm_Val     : STD_LOGIC_VECTOR(3 downto 0);
    signal Load_Imm    : STD_LOGIC;
    signal Add_Sub     : STD_LOGIC;
    signal Neg_En      : STD_LOGIC;
    signal Jump        : STD_LOGIC;
    signal Jump_Addr   : STD_LOGIC_VECTOR(2 downto 0);

begin

    DUT: Instruction_decoder port map(
        Instruction => Instruction,
        Reg_En      => Reg_En,
        Mux_Sel_A   => Mux_Sel_A,
        Mux_Sel_B   => Mux_Sel_B,
        Imm_Val     => Imm_Val,
        Load_Imm    => Load_Imm,
        Add_Sub     => Add_Sub,
        Neg_En      => Neg_En,
        Jump        => Jump,
        Jump_Addr   => Jump_Addr);

    process
    begin
        -- ── Test 1: NOP (opcode=000) ─────────────────────────────
        -- "000 000 000 000"
        Instruction <= "000000000000"; wait for 20 ns;
        assert Reg_En = "00000000" and Jump = '0' and Load_Imm = '0'
            report "FAIL: NOP defaults" severity error;

        -- ── Test 2: ADD R2, R0, R1 ───────────────────────────────
        -- opcode=001, Rd=010, Rs1=000, Rs2=001
        -- "001 010 000 001"
        Instruction <= "001010000001"; wait for 20 ns;
        assert Reg_En    = "00000100"   report "FAIL: ADD Reg_En (R2)"    severity error;
        assert Mux_Sel_A = "000"        report "FAIL: ADD Mux_Sel_A=R0"   severity error;
        assert Mux_Sel_B = "001"        report "FAIL: ADD Mux_Sel_B=R1"   severity error;
        assert Add_Sub   = '0'          report "FAIL: ADD Add_Sub=0"       severity error;
        assert Load_Imm  = '0'          report "FAIL: ADD Load_Imm=0"      severity error;
        assert Jump      = '0'          report "FAIL: ADD Jump=0"           severity error;

        -- ── Test 3: ADD R4, R2, R3 ───────────────────────────────
        -- opcode=001, Rd=100, Rs1=010, Rs2=011
        -- "001 100 010 011"
        Instruction <= "001100010011"; wait for 20 ns;
        assert Reg_En    = "00010000"   report "FAIL: ADD R4 Reg_En"       severity error;
        assert Mux_Sel_A = "010"        report "FAIL: ADD R4 Sel_A=R2"     severity error;
        assert Mux_Sel_B = "011"        report "FAIL: ADD R4 Sel_B=R3"     severity error;

        -- ── Test 4: JZR R0, addr=7 ──────────────────────────────
        -- opcode=010, Rd=000 (register to check), Rs1=111 (jump addr)
        -- "010 000 111 000"
        Instruction <= "010000111000"; wait for 20 ns;
        assert Jump      = '1'          report "FAIL: JZR Jump=1"          severity error;
        assert Mux_Sel_A = "000"        report "FAIL: JZR Mux_Sel_A=R0"   severity error;
        assert Jump_Addr = "111"        report "FAIL: JZR Jump_Addr=7"     severity error;
        assert Reg_En    = "00000000"   report "FAIL: JZR no Reg write"    severity error;
        assert Load_Imm  = '0'          report "FAIL: JZR Load_Imm=0"      severity error;

        -- ── Test 5: NEG R3, R1 ──────────────────────────────────
        -- opcode=011, Rd=011, Rs1=001
        -- "011 011 001 000"
        Instruction <= "011011001000"; wait for 20 ns;
        assert Reg_En    = "00001000"   report "FAIL: NEG Reg_En (R3)"     severity error;
        assert Mux_Sel_B = "001"        report "FAIL: NEG Mux_Sel_B=R1"   severity error;
        assert Add_Sub   = '1'          report "FAIL: NEG Add_Sub=1"       severity error;
        assert Neg_En    = '1'          report "FAIL: NEG Neg_En=1"        severity error;
        assert Jump      = '0'          report "FAIL: NEG Jump=0"           severity error;

        -- ── Test 6: MOVI R0, #5 ─────────────────────────────────
        -- opcode=100, Rd=000, imm in bits[5:2]="0101"
        -- "100 000 0101 00" → "100000010100"
        Instruction <= "100000010100"; wait for 20 ns;
        assert Reg_En   = "00000001"    report "FAIL: MOVI R0 Reg_En"      severity error;
        assert Imm_Val  = "0101"        report "FAIL: MOVI #5 Imm_Val"     severity error;
        assert Load_Imm = '1'           report "FAIL: MOVI Load_Imm=1"     severity error;
        assert Jump     = '0'           report "FAIL: MOVI Jump=0"          severity error;

        -- ── Test 7: MOVI R1, #3 ─────────────────────────────────
        -- opcode=100, Rd=001, imm="0011"
        -- "100 001 0011 00" → "100001001100"
        Instruction <= "100001001100"; wait for 20 ns;
        assert Reg_En  = "00000010"     report "FAIL: MOVI R1 Reg_En"      severity error;
        assert Imm_Val = "0011"         report "FAIL: MOVI #3 Imm_Val"     severity error;
        assert Load_Imm = '1'           report "FAIL: MOVI R1 Load_Imm"    severity error;

        -- ── Test 8: MOVI R5, #1 ─────────────────────────────────
        -- opcode=100, Rd=101, imm="0001"
        -- "100 101 0001 00" → "100101000100"
        Instruction <= "100101000100"; wait for 20 ns;
        assert Reg_En  = "00100000"     report "FAIL: MOVI R5 Reg_En"      severity error;
        assert Imm_Val = "0001"         report "FAIL: MOVI #1 Imm_Val"     severity error;

        report "tb_Instruction_decoder: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
