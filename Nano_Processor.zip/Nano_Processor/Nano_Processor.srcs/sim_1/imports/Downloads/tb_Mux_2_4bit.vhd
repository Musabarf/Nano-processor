----------------------------------------------------------------------------------
-- Testbench : tb_Mux_2_4bit
-- DUT       : Mux_2_4bit
-- Tests     : Sel=0 selects I0, Sel=1 selects I1
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Mux_2_4bit is
end tb_Mux_2_4bit;

architecture Behavioral of tb_Mux_2_4bit is

    component Mux_2_4bit
        Port ( I0  : in  STD_LOGIC_VECTOR(3 downto 0);
               I1  : in  STD_LOGIC_VECTOR(3 downto 0);
               Sel : in  STD_LOGIC;
               Y   : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    signal I0, I1 : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal Sel    : STD_LOGIC := '0';
    signal Y      : STD_LOGIC_VECTOR(3 downto 0);

begin

    DUT: Mux_2_4bit port map(I0=>I0, I1=>I1, Sel=>Sel, Y=>Y);

    process
    begin
        -- Test 1: Sel=0 → I0
        I0 <= "1010"; I1 <= "0101"; Sel <= '0'; wait for 20 ns;
        assert Y = "1010" report "FAIL: Sel=0, I0=A" severity error;

        -- Test 2: Sel=1 → I1
        Sel <= '1'; wait for 20 ns;
        assert Y = "0101" report "FAIL: Sel=1, I1=5" severity error;

        -- Test 3: write-back use-case: ALU=6, Imm=9, Sel=0 (ALU)
        I0 <= "0110"; I1 <= "1001"; Sel <= '0'; wait for 20 ns;
        assert Y = "0110" report "FAIL: WB mux ALU result" severity error;

        -- Test 4: write-back use-case: Load_Imm=1 → I1=immediate
        Sel <= '1'; wait for 20 ns;
        assert Y = "1001" report "FAIL: WB mux immediate" severity error;

        -- Test 5: All zeros
        I0 <= "0000"; I1 <= "0000"; Sel <= '0'; wait for 20 ns;
        assert Y = "0000" report "FAIL: Both 0, Sel=0" severity error;

        -- Test 6: All ones
        I0 <= "1111"; I1 <= "1111"; Sel <= '1'; wait for 20 ns;
        assert Y = "1111" report "FAIL: Both F, Sel=1" severity error;

        report "tb_Mux_2_4bit: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
