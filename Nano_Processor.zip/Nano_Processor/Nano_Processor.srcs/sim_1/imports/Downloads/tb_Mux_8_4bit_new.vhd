----------------------------------------------------------------------------------
-- Testbench : tb_Mux_8_4bit_new
-- DUT       : Mux_8_4bit_new
-- Tests     : selection with Enable=1 and output=0000 when Enable=0
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_Mux_8_4bit_new is
end tb_Mux_8_4bit_new;

architecture Behavioral of tb_Mux_8_4bit_new is

    component Mux_8_4bit_new
        Port ( I0, I1, I2, I3,
               I4, I5, I6, I7 : in  STD_LOGIC_VECTOR(3 downto 0);
               Sel             : in  STD_LOGIC_VECTOR(2 downto 0);
               Enable          : in  STD_LOGIC;
               Y               : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    signal I0 : STD_LOGIC_VECTOR(3 downto 0) := "1000";
    signal I1 : STD_LOGIC_VECTOR(3 downto 0) := "1001";
    signal I2 : STD_LOGIC_VECTOR(3 downto 0) := "1010";
    signal I3 : STD_LOGIC_VECTOR(3 downto 0) := "1011";
    signal I4 : STD_LOGIC_VECTOR(3 downto 0) := "1100";
    signal I5 : STD_LOGIC_VECTOR(3 downto 0) := "1101";
    signal I6 : STD_LOGIC_VECTOR(3 downto 0) := "1110";
    signal I7 : STD_LOGIC_VECTOR(3 downto 0) := "1111";
    signal Sel    : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal Enable : STD_LOGIC := '0';
    signal Y      : STD_LOGIC_VECTOR(3 downto 0);

begin

    DUT: Mux_8_4bit_new port map(
        I0=>I0,I1=>I1,I2=>I2,I3=>I3,
        I4=>I4,I5=>I5,I6=>I6,I7=>I7,
        Sel=>Sel, Enable=>Enable, Y=>Y);

    process
    begin
        -- ── Enable = 0 → Y must be 0000 regardless of Sel ──────
        Enable <= '0';
        Sel <= "000"; wait for 20 ns;
        assert Y = "0000" report "FAIL: Enable=0, Sel=0" severity error;

        Sel <= "101"; wait for 20 ns;
        assert Y = "0000" report "FAIL: Enable=0, Sel=5" severity error;

        -- ── Enable = 1 → normal mux selection ──────────────────
        Enable <= '1';
        Sel <= "000"; wait for 20 ns;
        assert Y = "1000" report "FAIL: Enable=1, Sel=0" severity error;

        Sel <= "001"; wait for 20 ns;
        assert Y = "1001" report "FAIL: Enable=1, Sel=1" severity error;

        Sel <= "010"; wait for 20 ns;
        assert Y = "1010" report "FAIL: Enable=1, Sel=2" severity error;

        Sel <= "011"; wait for 20 ns;
        assert Y = "1011" report "FAIL: Enable=1, Sel=3" severity error;

        Sel <= "100"; wait for 20 ns;
        assert Y = "1100" report "FAIL: Enable=1, Sel=4" severity error;

        Sel <= "101"; wait for 20 ns;
        assert Y = "1101" report "FAIL: Enable=1, Sel=5" severity error;

        Sel <= "110"; wait for 20 ns;
        assert Y = "1110" report "FAIL: Enable=1, Sel=6" severity error;

        Sel <= "111"; wait for 20 ns;
        assert Y = "1111" report "FAIL: Enable=1, Sel=7" severity error;

        -- ── Toggle Enable mid-operation ─────────────────────────
        Sel <= "011"; Enable <= '1'; wait for 20 ns;
        assert Y = "1011" report "FAIL: Toggle on, Sel=3" severity error;

        Enable <= '0'; wait for 20 ns;
        assert Y = "0000" report "FAIL: Toggle off" severity error;

        report "tb_Mux_8_4bit_new: ALL TESTS DONE" severity note;
        wait;
    end process;

end Behavioral;
