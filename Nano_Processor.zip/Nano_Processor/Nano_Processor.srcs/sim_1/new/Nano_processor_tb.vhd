----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 03:25:39 PM
-- Design Name: 
-- Module Name: Nano_processor_tb - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Nano_processor_tb is
end Nano_processor_tb;

architecture Behavioral of Nano_processor_tb is

    -- Component declaration
    component Nano_processor
        Port ( Clk      : in  STD_LOGIC;
               Reset    : in  STD_LOGIC;
               Result   : out STD_LOGIC_VECTOR(3 downto 0);
               Overflow : out STD_LOGIC;
               Zero     : out STD_LOGIC);
    end component;

    -- Testbench signals
    signal Clk      : STD_LOGIC := '0';
    signal Reset    : STD_LOGIC := '1';
    signal Result   : STD_LOGIC_VECTOR(3 downto 0);
    signal Overflow : STD_LOGIC;
    signal Zero     : STD_LOGIC;

    constant CLK_PERIOD : time := 10 ns; -- 100 MHz

    -- Helper: convert SLV to integer string for reports
    function slv_to_str(s : STD_LOGIC_VECTOR) return string is
    begin
        return integer'image(to_integer(unsigned(s)));
    end function;

begin

    -- Instantiate Unit Under Test
    UUT: Nano_processor
        port map (
            Clk      => Clk,
            Reset    => Reset,
            Result   => Result,
            Overflow => Overflow,
            Zero     => Zero);

    -- ?????????????????????????????????????????????
    -- CLOCK GENERATOR: 100 MHz (10 ns period)
    -- ?????????????????????????????????????????????
    clk_proc: process
    begin
        Clk <= '0'; wait for CLK_PERIOD / 2;
        Clk <= '1'; wait for CLK_PERIOD / 2;
    end process;

    -- ?????????????????????????????????????????????
    -- STIMULUS PROCESS
    -- ?????????????????????????????????????????????
    stim_proc: process
    begin

        -- ?? RESET ??????????????????????????????????
        Reset <= '1';
        wait for CLK_PERIOD * 2;
        Reset <= '0';
        wait for 1 ns; -- small offset past clock edge
        report "[TB] Reset released - execution starts" severity note;

        -- ?? CYCLE 1: MOVI R0, #5 ??????????????????
        -- Instruction: 100 000 0101 00
        -- R0 will hold 5 after this cycle
        wait for CLK_PERIOD;
        report "[C1] MOVI R0,#5  | Result=" & slv_to_str(Result)
               severity note;

        -- ?? CYCLE 2: MOVI R1, #3 ??????????????????
        -- Instruction: 100 001 0011 00
        -- R1 will hold 3 after this cycle
        wait for CLK_PERIOD;
        report "[C2] MOVI R1,#3  | Result=" & slv_to_str(Result)
               severity note;

        -- ?? CYCLE 3: ADD R2, R0, R1 ???????????????
        -- Instruction: 001 010 000 001
        -- R2 = R0 + R1 = 5 + 3 = 8 = "1000"
        wait for CLK_PERIOD;
        report "[C3] ADD R2,R0,R1 | Result=" & slv_to_str(Result) &
               " Overflow=" & std_logic'image(Overflow) severity note;
        assert Result = "1000"
            report "[FAIL] C3: ADD expected 8 (1000), got " & slv_to_str(Result)
            severity error;
        assert Overflow = '0'
            report "[FAIL] C3: No overflow expected" severity error;

        -- ?? CYCLE 4: NEG R3, R1 ???????????????????
        -- Instruction: 011 011 001 000
        -- R3 = 0 - R1 = 0 - 3 = -3 = "1101" (4-bit 2's complement)
        -- Overflow flag will be set (borrow occurred)
        wait for CLK_PERIOD;
        report "[C4] NEG R3,R1    | Result=" & slv_to_str(Result) &
               " (expect 13=1101=-3)  Overflow=" &
               std_logic'image(Overflow) severity note;
        assert Result = "1101"
            report "[FAIL] C4: NEG expected -3 (1101), got " & slv_to_str(Result)
            severity error;

        -- ?? CYCLE 5: ADD R4, R2, R3 ???????????????
        -- Instruction: 001 100 010 011
        -- R4 = R2 + R3 = 8 + (-3) = 5 = "0101"
        wait for CLK_PERIOD;
        report "[C5] ADD R4,R2,R3 | Result=" & slv_to_str(Result) &
               " (expect 5=0101)" severity note;
        assert Result = "0101"
            report "[FAIL] C5: ADD expected 5 (0101), got " & slv_to_str(Result)
            severity error;

        -- ?? CYCLE 6: JZR R0, 7 ????????????????????
        -- Instruction: 010 000 111 000
        -- R0=5 (not zero) ? Zero_check=0 ? NO JUMP ? PC?6
        wait for CLK_PERIOD;
        report "[C6] JZR R0,7     | Zero=" & std_logic'image(Zero) &
               " (expect 0 = no jump taken)" severity note;
        assert Zero = '0'
            report "[FAIL] C6: JZR should NOT jump (R0=5 != 0)"
            severity error;

        -- ?? CYCLE 7: MOVI R5, #1 ??????????????????
        -- Instruction: 100 101 0001 00
        -- R5 will hold 1
        wait for CLK_PERIOD;
        report "[C7] MOVI R5,#1   | Result=" & slv_to_str(Result)
               severity note;

        -- ?? CYCLE 8: ADD R6, R0, R1 ???????????????
        -- Instruction: 001 110 000 001
        -- R6 = R0 + R1 = 5 + 3 = 8 = "1000"
        wait for CLK_PERIOD;
        report "[C8] ADD R6,R0,R1 | Result=" & slv_to_str(Result) &
               " (expect 8=1000)" severity note;
        assert Result = "1000"
            report "[FAIL] C8: ADD expected 8 (1000), got " & slv_to_str(Result)
            severity error;

        -- ?? EXTRA CYCLES: observe PC wrap-around ??
        wait for CLK_PERIOD * 4;

        report "[TB] ? All assertions passed. Simulation complete."
               severity note;
        wait; -- stop simulation

    end process;

    -- ?????????????????????????????????????????????
    -- MONITOR PROCESS: prints every rising edge
    -- ?????????????????????????????????????????????
    monitor_proc: process(Clk)
        variable cycle_cnt : integer := 0;
    begin
        if rising_edge(Clk) and Reset = '0' then
            cycle_cnt := cycle_cnt + 1;
            report "CLK#" & integer'image(cycle_cnt) &
                   " | Result=" & slv_to_str(Result) &
                   " OVF=" & std_logic'image(Overflow) &
                   " Z=" & std_logic'image(Zero)
                   severity note;
        end if;
    end process;

end Behavioral;
entity Nano_processor_tb is
--  Port ( );
end Nano_processor_tb;

architecture Behavioral of Nano_processor_tb is

begin


end Behavioral;
