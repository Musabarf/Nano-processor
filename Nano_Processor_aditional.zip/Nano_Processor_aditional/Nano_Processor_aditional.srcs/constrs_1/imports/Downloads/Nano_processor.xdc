## =============================================================================
## Nano-processor XDC Constraints  -  Basys3 (xc7a35tcpg236-1)
## =============================================================================

## ---- Clock (100 MHz) --------------------------------------------------------
set_property PACKAGE_PIN W5       [get_ports Clk]
set_property IOSTANDARD LVCMOS33  [get_ports Clk]
create_clock -period 10.000 -name sys_clk [get_ports Clk]

## ---- Reset : BTNC (centre button, active high) ------------------------------
set_property PACKAGE_PIN U18      [get_ports Reset]
set_property IOSTANDARD LVCMOS33  [get_ports Reset]

## =============================================================================
## LED outputs
## =============================================================================

## Result[3:0] -> LD3..LD0
set_property PACKAGE_PIN U16  [get_ports {Result[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Result[0]}]
set_property PACKAGE_PIN E19  [get_ports {Result[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Result[1]}]
set_property PACKAGE_PIN U19  [get_ports {Result[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Result[2]}]
set_property PACKAGE_PIN V19  [get_ports {Result[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Result[3]}]

## Overflow -> LD4
set_property PACKAGE_PIN W18  [get_ports Overflow]
set_property IOSTANDARD LVCMOS33  [get_ports Overflow]

## Zero -> LD5
set_property PACKAGE_PIN U15  [get_ports Zero]
set_property IOSTANDARD LVCMOS33  [get_ports Zero]

## GT -> LD6
set_property PACKAGE_PIN U14  [get_ports GT]
set_property IOSTANDARD LVCMOS33  [get_ports GT]

## LT -> LD7
set_property PACKAGE_PIN V14  [get_ports LT]
set_property IOSTANDARD LVCMOS33  [get_ports LT]

## R7_out[3:0] -> LD11..LD8  (if this port exists on your top-level entity)
set_property PACKAGE_PIN V13  [get_ports {R7_out[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7_out[0]}]
set_property PACKAGE_PIN V3   [get_ports {R7_out[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7_out[1]}]
set_property PACKAGE_PIN W3   [get_ports {R7_out[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7_out[2]}]
set_property PACKAGE_PIN U3   [get_ports {R7_out[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7_out[3]}]

## =============================================================================
## 7-Segment Display (active-low on Basys3)
## seg[6:0] = {g, f, e, d, c, b, a}
## =============================================================================

set_property PACKAGE_PIN W7  [get_ports {seg[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {seg[0]}]
set_property PACKAGE_PIN W6  [get_ports {seg[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {seg[1]}]
set_property PACKAGE_PIN U8  [get_ports {seg[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {seg[2]}]
set_property PACKAGE_PIN V8  [get_ports {seg[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {seg[3]}]
set_property PACKAGE_PIN U5  [get_ports {seg[4]}]
set_property IOSTANDARD LVCMOS33 [get_ports {seg[4]}]
set_property PACKAGE_PIN V5  [get_ports {seg[5]}]
set_property IOSTANDARD LVCMOS33 [get_ports {seg[5]}]
set_property PACKAGE_PIN U7  [get_ports {seg[6]}]
set_property IOSTANDARD LVCMOS33 [get_ports {seg[6]}]

## Anodes an[3:0]  (an[0]=rightmost digit, an[3]=leftmost)
set_property PACKAGE_PIN U2  [get_ports {an[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {an[0]}]
set_property PACKAGE_PIN U4  [get_ports {an[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {an[1]}]
set_property PACKAGE_PIN V4  [get_ports {an[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {an[2]}]
set_property PACKAGE_PIN W4  [get_ports {an[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {an[3]}]
