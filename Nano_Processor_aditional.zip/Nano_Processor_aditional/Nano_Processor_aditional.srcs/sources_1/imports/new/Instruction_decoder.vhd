library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

-- ============================================================
-- Instruction_decoder — corrected to match lab spec
-- 12-bit instruction format:
--   MOVI R,d  : 10 RRR 000 dddd  (opcode=10)
--   ADD Ra,Rb : 00 RaRaRa RbRbRb 0000  (opcode=00)
--   NEG R     : 01 RRR 000000000  (opcode=01)
--   JZR R,d   : 11 RRR 0000 ddd  (opcode=11)
-- ============================================================
entity Instruction_decoder is
    Port ( Instruction : in  STD_LOGIC_VECTOR(11 downto 0);
           Reg_En      : out STD_LOGIC_VECTOR(7 downto 0);
           Mux_Sel_A   : out STD_LOGIC_VECTOR(2 downto 0);
           Mux_Sel_B   : out STD_LOGIC_VECTOR(2 downto 0);
           Imm_Val     : out STD_LOGIC_VECTOR(3 downto 0);
           Load_Imm    : out STD_LOGIC;
           Add_Sub     : out STD_LOGIC;
           Neg_En      : out STD_LOGIC;
           Jump        : out STD_LOGIC;
           Jump_Addr   : out STD_LOGIC_VECTOR(2 downto 0));
end Instruction_decoder;

architecture Behavioral of Instruction_decoder is
    signal opcode : STD_LOGIC_VECTOR(1 downto 0); -- bits [11:10]
    signal Rd     : STD_LOGIC_VECTOR(2 downto 0); -- bits [9:7]
    signal Rb     : STD_LOGIC_VECTOR(2 downto 0); -- bits [6:4]
begin
    opcode <= Instruction(11 downto 10);
    Rd     <= Instruction(9  downto 7);
    Rb     <= Instruction(6  downto 4);

    process(Instruction, opcode, Rd, Rb)
        variable en : STD_LOGIC_VECTOR(7 downto 0);
    begin
        -- safe defaults
        Reg_En    <= "00000000";
        Mux_Sel_A <= "000";
        Mux_Sel_B <= "000";
        Imm_Val   <= "0000";
        Load_Imm  <= '0';
        Add_Sub   <= '0';
        Neg_En    <= '0';
        Jump      <= '0';
        Jump_Addr <= "000";

        -- build register enable (R0 is read-only/hardwired 0, never written)
        en := "00000000";
        if Rd /= "000" then
            en(to_integer(unsigned(Rd))) := '1';
        end if;

        case opcode is

            when "00" =>   -- ADD Ra, Rb  =>  Ra = Ra + Rb
                Reg_En    <= en;
                Mux_Sel_A <= Rd;    -- Ra is source 1 (also destination)
                Mux_Sel_B <= Rb;    -- Rb is source 2  (bits [6:4])
                Add_Sub   <= '0';

            when "01" =>   -- NEG R  =>  R = 0 - R  (uses R0=0000 as A input)
                Reg_En    <= en;
                Mux_Sel_A <= "000"; -- select R0 = "0000" (hardwired zero)
                Mux_Sel_B <= Rd;    -- R is the operand to negate
                Add_Sub   <= '1';   -- perform subtraction: 0 - R
                Neg_En    <= '1';

            when "10" =>   -- MOVI R, d  =>  R = immediate
                Reg_En    <= en;
                Imm_Val   <= Instruction(3 downto 0); -- bits [3:0]
                Load_Imm  <= '1';

            when "11" =>   -- JZR R, d  =>  if R==0 then PC=d
                Mux_Sel_A <= Rd;                      -- register to check
                Jump      <= '1';
                Jump_Addr <= Instruction(2 downto 0); -- bits [2:0]

            when others => null;  -- NOP / undefined

        end case;
    end process;
end Behavioral;
