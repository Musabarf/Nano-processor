----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 02:33:05 PM
-- Design Name: 
-- Module Name: 3bit_adder - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

use IEEE.NUMERIC_STD.ALL;

entity three_bit_adder  is
    Port ( A    : in  STD_LOGIC_VECTOR(2 downto 0);
           B    : in  STD_LOGIC_VECTOR(2 downto 0);
           Cin  : in  STD_LOGIC;
           Sum  : out STD_LOGIC_VECTOR(2 downto 0);
           Cout : out STD_LOGIC);
end three_bit_adder ;

architecture Behavioral of three_bit_adder  is
    signal temp : STD_LOGIC_VECTOR(3 downto 0);
begin
    temp <= std_logic_vector(
               unsigned('0' & A) +
               unsigned('0' & B) +
               ("000" & Cin));
    Sum  <= temp(2 downto 0);
    Cout <= temp(3);
end Behavioral;
