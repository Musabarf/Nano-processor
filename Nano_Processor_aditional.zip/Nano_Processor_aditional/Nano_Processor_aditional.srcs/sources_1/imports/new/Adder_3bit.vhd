----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 02:11:38 PM
-- Design Name: 
-- Module Name: adder_3bit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity pc_incrementer  is
    Port ( A    : in  STD_LOGIC_VECTOR(2 downto 0);
           Sum  : out STD_LOGIC_VECTOR(2 downto 0);
           Cout : out STD_LOGIC);
end pc_incrementer ;

architecture Structural of pc_incrementer  is
    component three_bit_adder 
        Port ( A    : in  STD_LOGIC_VECTOR(2 downto 0);
               B    : in  STD_LOGIC_VECTOR(2 downto 0);
               Cin  : in  STD_LOGIC;
               Sum  : out STD_LOGIC_VECTOR(2 downto 0);
               Cout : out STD_LOGIC);
    end component;
begin
    -- Adds 1 to PC: B = "001", Cin = '0'
    U1: three_bit_adder
        port map (A    => A,
                  B    => "001",
                  Cin  => '0',
                  Sum  => Sum,
                  Cout => Cout);
end Structural;
