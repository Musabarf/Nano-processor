----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 01:59:44 PM
-- Design Name: 
-- Module Name: Tri_State_buffer - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Tri_State_buffer is
    Port ( data_in  : in  STD_LOGIC;
           enable   : in  STD_LOGIC;
           data_out : out STD_LOGIC);
end Tri_State_buffer;

architecture Behavioral of Tri_State_buffer is
begin
    data_out <= data_in when enable = '1' else 'Z';
end Behavioral;
