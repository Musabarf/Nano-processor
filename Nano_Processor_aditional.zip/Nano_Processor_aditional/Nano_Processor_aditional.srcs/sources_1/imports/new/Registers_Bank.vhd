----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 02:41:37 PM
-- Design Name: 
-- Module Name: Registers_Bank - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Registers_Bank is
    Port ( D       : in  STD_LOGIC_VECTOR(3 downto 0);
           Reg_En  : in  STD_LOGIC_VECTOR(7 downto 0);
           Clk     : in  STD_LOGIC;
           Reset   : in  STD_LOGIC;
           Q0, Q1, Q2, Q3,
           Q4, Q5, Q6, Q7 : out STD_LOGIC_VECTOR(3 downto 0));
end Registers_Bank;

architecture Structural of Registers_Bank is
    component Reg_4bit
        Port ( D     : in  STD_LOGIC_VECTOR(3 downto 0);
               Load  : in  STD_LOGIC;
               Reset : in  STD_LOGIC;
               Clk   : in  STD_LOGIC;
               Q     : out STD_LOGIC_VECTOR(3 downto 0));
    end component;
begin
    R0: Reg_4bit port map(D,Reg_En(0),Reset,Clk,Q0);
    R1: Reg_4bit port map(D,Reg_En(1),Reset,Clk,Q1);
    R2: Reg_4bit port map(D,Reg_En(2),Reset,Clk,Q2);
    R3: Reg_4bit port map(D,Reg_En(3),Reset,Clk,Q3);
    R4: Reg_4bit port map(D,Reg_En(4),Reset,Clk,Q4);
    R5: Reg_4bit port map(D,Reg_En(5),Reset,Clk,Q5);
    R6: Reg_4bit port map(D,Reg_En(6),Reset,Clk,Q6);
    R7: Reg_4bit port map(D,Reg_En(7),Reset,Clk,Q7);
end Structural;