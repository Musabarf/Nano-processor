library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- ============================================================
-- ROM — Step 4 program: compute 1+2+3=6, store in R7
--
-- Instruction encoding (2-bit opcode, lab spec):
--   MOVI R,d  : 10 RRR 000 dddd
--   ADD Ra,Rb : 00 RaRaRa RbRbRb 0000
--   NEG R     : 01 RRR 000000000
--   JZR R,d   : 11 RRR 0000 ddd
--
-- Program:
--   addr 0: MOVI R1, #1  → 10 001 000 0001 = "100010000001"
--   addr 1: MOVI R2, #2  → 10 010 000 0010 = "100100000010"
--   addr 2: MOVI R3, #3  → 10 011 000 0011 = "100110000011"
--   addr 3: ADD  R7, R1  → 00 111 001 0000 = "001110010000" (R7 = 0+1 = 1)
--   addr 4: ADD  R7, R2  → 00 111 010 0000 = "001110100000" (R7 = 1+2 = 3)
--   addr 5: ADD  R7, R3  → 00 111 011 0000 = "001110110000" (R7 = 3+3 = 6)
--   addr 6: NOP          → "000000000000"
--   addr 7: NOP          → "000000000000"
-- ============================================================
entity ROM is
    Port ( address : in  STD_LOGIC_VECTOR(2 downto 0);
           data    : out STD_LOGIC_VECTOR(11 downto 0));
end ROM;

architecture Behavioral of ROM is
begin
    process(address)
    begin
        case address is
            --                            gfedcba
            when "000" => data <= "101110000000"; -- MOVI R7, #0  (reset accumulator)
            when "001" => data <= "100010000001"; -- MOVI R1, #1
            when "010" => data <= "100100000010"; -- MOVI R2, #2
            when "011" => data <= "100110000011"; -- MOVI R3, #3
            when "100" => data <= "001110010000"; -- ADD  R7, R1  ? R7=1
            when "101" => data <= "001110100000"; -- ADD  R7, R2  ? R7=3
            when "110" => data <= "001110110000"; -- ADD  R7, R3  ? R7=6
            when "111" => data <= "110000000000"; -- JZR  R0, 0   ? always jump (R0=0 always)
            when others => data <= "000000000000";
        end case;
    end process;
end Behavioral;
