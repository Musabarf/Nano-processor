----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 02:40:02 PM
-- Design Name: 
-- Module Name: Mux_8_4bit_new - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Mux_8_4bit_new is
    Port ( I0, I1, I2, I3,
           I4, I5, I6, I7 : in  STD_LOGIC_VECTOR(3 downto 0);
           Sel             : in  STD_LOGIC_VECTOR(2 downto 0);
           Enable          : in  STD_LOGIC;
           Y               : out STD_LOGIC_VECTOR(3 downto 0));
end Mux_8_4bit_new;

architecture Behavioral of Mux_8_4bit_new is
    signal sel_out : STD_LOGIC_VECTOR(3 downto 0);
begin
    with Sel select
        sel_out <= I0 when "000",
                   I1 when "001",
                   I2 when "010",
                   I3 when "011",
                   I4 when "100",
                   I5 when "101",
                   I6 when "110",
                   I7 when others;
    Y <= sel_out when Enable = '1' else "0000";
end Behavioral;
