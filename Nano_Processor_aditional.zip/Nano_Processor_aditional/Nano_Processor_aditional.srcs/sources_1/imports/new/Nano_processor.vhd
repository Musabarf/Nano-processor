library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

-- ============================================================
-- Nano_processor — corrected top-level (lab spec compliant)
-- Outputs: R7_out on LD0-LD3, seg/an for 7-seg display
--          Zero on LD14, Overflow on LD15
-- Clock: 100 MHz divided down to ~1 Hz by Slow_Clock
-- ============================================================
entity Nano_processor is
    Port ( Clk      : in  STD_LOGIC;             -- 100 MHz from board
           Reset    : in  STD_LOGIC;             -- BTNC
           R7_out   : out STD_LOGIC_VECTOR(3 downto 0); -- to LD0-LD3
           Overflow : out STD_LOGIC;             -- to LD15
           Zero     : out STD_LOGIC;             -- to LD14
           seg      : out STD_LOGIC_VECTOR(6 downto 0); -- 7-seg cathodes
           an       : out STD_LOGIC_VECTOR(3 downto 0));-- 7-seg anodes
end Nano_processor;

architecture Structural of Nano_processor is

    -- ── Component declarations ─────────────────────────────
    component Slow_Clock
        port(Clk_100MHz:in STD_LOGIC; Reset:in STD_LOGIC;
             Clk_slow:out STD_LOGIC);
    end component;

    component Program_Counter
        port(D:in STD_LOGIC_VECTOR(2 downto 0);
             Load,Reset,Clk:in STD_LOGIC;
             Q:out STD_LOGIC_VECTOR(2 downto 0));
    end component;

    component pc_incrementer
        port(A:in STD_LOGIC_VECTOR(2 downto 0);
             Sum:out STD_LOGIC_VECTOR(2 downto 0);
             Cout:out STD_LOGIC);
    end component;

    component Mux_2_3bit
        port(I0,I1:in STD_LOGIC_VECTOR(2 downto 0);
             Sel:in STD_LOGIC;
             Y:out STD_LOGIC_VECTOR(2 downto 0));
    end component;

    component ROM
        port(address:in STD_LOGIC_VECTOR(2 downto 0);
             data:out STD_LOGIC_VECTOR(11 downto 0));
    end component;

    component Instruction_decoder
        port(Instruction:in STD_LOGIC_VECTOR(11 downto 0);
             Reg_En:out STD_LOGIC_VECTOR(7 downto 0);
             Mux_Sel_A,Mux_Sel_B,Jump_Addr:out STD_LOGIC_VECTOR(2 downto 0);
             Imm_Val:out STD_LOGIC_VECTOR(3 downto 0);
             Load_Imm,Add_Sub,Neg_En,Jump:out STD_LOGIC);
    end component;

    component Registers_Bank
        port(D:in STD_LOGIC_VECTOR(3 downto 0);
             Reg_En:in STD_LOGIC_VECTOR(7 downto 0);
             Clk,Reset:in STD_LOGIC;
             Q0,Q1,Q2,Q3,Q4,Q5,Q6,Q7:out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    component Mux_8_4bit
        port(I0,I1,I2,I3,I4,I5,I6,I7:in STD_LOGIC_VECTOR(3 downto 0);
             Sel:in STD_LOGIC_VECTOR(2 downto 0);
             Y:out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    component Add_Sub_unit
        port(A,B:in STD_LOGIC_VECTOR(3 downto 0);
             Add_Sub:in STD_LOGIC;
             Result:out STD_LOGIC_VECTOR(3 downto 0);
             Overflow:out STD_LOGIC;
             Zero:out STD_LOGIC);
    end component;

    component Mux_2_4bit
        port(I0,I1:in STD_LOGIC_VECTOR(3 downto 0);
             Sel:in STD_LOGIC;
             Y:out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    component Seven_Seg_Decoder
        port(num:in STD_LOGIC_VECTOR(3 downto 0);
             seg:out STD_LOGIC_VECTOR(6 downto 0));
    end component;

    -- ── Internal signals ──────────────────────────────────
    signal Clk_slow   : STD_LOGIC;
    signal PC_out     : STD_LOGIC_VECTOR(2 downto 0);
    signal PC_inc     : STD_LOGIC_VECTOR(2 downto 0);
    signal PC_next    : STD_LOGIC_VECTOR(2 downto 0);
    signal PC_cout    : STD_LOGIC;
    signal Instruction: STD_LOGIC_VECTOR(11 downto 0);
    signal Reg_En     : STD_LOGIC_VECTOR(7 downto 0);
    signal Mux_Sel_A  : STD_LOGIC_VECTOR(2 downto 0);
    signal Mux_Sel_B  : STD_LOGIC_VECTOR(2 downto 0);
    signal Jump_Addr  : STD_LOGIC_VECTOR(2 downto 0);
    signal Imm_Val    : STD_LOGIC_VECTOR(3 downto 0);
    signal Load_Imm   : STD_LOGIC;
    signal Add_Sub    : STD_LOGIC;
    signal Neg_En     : STD_LOGIC;
    signal Jump       : STD_LOGIC;
    signal Jump_En    : STD_LOGIC;
    signal Q0,Q1,Q2,Q3,Q4,Q5,Q6,Q7 : STD_LOGIC_VECTOR(3 downto 0);
    signal ALU_A      : STD_LOGIC_VECTOR(3 downto 0);
    signal ALU_B      : STD_LOGIC_VECTOR(3 downto 0);
    signal ALU_Result : STD_LOGIC_VECTOR(3 downto 0);
    signal ALU_Ovf    : STD_LOGIC;
    signal ALU_Zero   : STD_LOGIC;
    signal Reg_In     : STD_LOGIC_VECTOR(3 downto 0);
    signal Zero_check : STD_LOGIC;
    signal R7_sig     : STD_LOGIC_VECTOR(3 downto 0);

begin

    -- 1. Clock divider (~1 Hz slow clock for visible LED output)
    CLK_DIV: Slow_Clock
        port map(Clk_100MHz => Clk,
                 Reset      => Reset,
                 Clk_slow   => Clk_slow);

    -- 2. Program Counter (clocked by slow clock)
    PC: Program_Counter
        port map(D     => PC_next,
                 Load  => '1',
                 Reset => Reset,
                 Clk   => Clk_slow,
                 Q     => PC_out);

    -- 3. PC + 1 incrementer
    INC: pc_incrementer
        port map(A    => PC_out,
                 Sum  => PC_inc,
                 Cout => PC_cout);

    -- 4. Next PC: PC+1 or jump address
    --    Jump taken only when Jump=1 AND checked register is zero
    Zero_check <= '1' when ALU_A = "0000" else '0';
    Jump_En    <= Jump and Zero_check;

    PCMUX: Mux_2_3bit
        port map(I0  => PC_inc,
                 I1  => Jump_Addr,
                 Sel => Jump_En,
                 Y   => PC_next);

    -- 5. Program ROM
    IROM: ROM
        port map(address => PC_out,
                 data    => Instruction);

    -- 6. Instruction Decoder
    ID: Instruction_decoder
        port map(Instruction => Instruction,
                 Reg_En      => Reg_En,
                 Mux_Sel_A   => Mux_Sel_A,
                 Mux_Sel_B   => Mux_Sel_B,
                 Imm_Val     => Imm_Val,
                 Load_Imm    => Load_Imm,
                 Add_Sub     => Add_Sub,
                 Neg_En      => Neg_En,
                 Jump        => Jump,
                 Jump_Addr   => Jump_Addr);

    -- 7. Register Bank (R0 = "0000" hardwired inside)
    RB: Registers_Bank
        port map(D      => Reg_In,
                 Reg_En => Reg_En,
                 Clk    => Clk_slow,
                 Reset  => Reset,
                 Q0     => Q0, Q1 => Q1, Q2 => Q2, Q3 => Q3,
                 Q4     => Q4, Q5 => Q5, Q6 => Q6, Q7 => Q7);

    -- Store Q7 for output
    R7_sig <= Q7;

    -- 8. MUX for ALU input A (Rs1 / Ra)
    MUXA: Mux_8_4bit
        port map(I0=>Q0,I1=>Q1,I2=>Q2,I3=>Q3,
                 I4=>Q4,I5=>Q5,I6=>Q6,I7=>Q7,
                 Sel => Mux_Sel_A,
                 Y   => ALU_A);

    -- 9. MUX for ALU input B (Rb / register to negate)
    MUXB: Mux_8_4bit
        port map(I0=>Q0,I1=>Q1,I2=>Q2,I3=>Q3,
                 I4=>Q4,I5=>Q5,I6=>Q6,I7=>Q7,
                 Sel => Mux_Sel_B,
                 Y   => ALU_B);

    -- 10. ALU (Add/Subtract unit)
    ALU: Add_Sub_unit
        port map(A        => ALU_A,
                 B        => ALU_B,
                 Add_Sub  => Add_Sub,
                 Result   => ALU_Result,
                 Overflow => ALU_Ovf,
                 Zero     => ALU_Zero);

    -- 11. Write-back MUX: ALU result or immediate value
    WBMUX: Mux_2_4bit
        port map(I0  => ALU_Result,
                 I1  => Imm_Val,
                 Sel => Load_Imm,
                 Y   => Reg_In);

    -- 12. Seven-segment decoder for R7
    SEG_DEG: Seven_Seg_Decoder
        port map(num => R7_sig,
                 seg => seg);

    -- Enable only the rightmost digit (AN0 active low)
    an <= "1110";

    -- 13. Top-level outputs
    R7_out   <= R7_sig;
    Overflow <= ALU_Ovf;
    Zero     <= ALU_Zero;

end Structural;
