----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/29/2026 02:36:56 PM
-- Design Name: 
-- Module Name: Add_Sub_unit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

use IEEE.NUMERIC_STD.ALL;

entity Add_Sub_unit is
    Port ( A        : in  STD_LOGIC_VECTOR(3 downto 0);
           B        : in  STD_LOGIC_VECTOR(3 downto 0);
           Add_Sub  : in  STD_LOGIC;  -- 0=Add, 1=Sub
           Result   : out STD_LOGIC_VECTOR(3 downto 0);
           Overflow : out STD_LOGIC;
           Zero     : out STD_LOGIC);
end Add_Sub_unit;

architecture Behavioral of Add_Sub_unit is
    signal temp : STD_LOGIC_VECTOR(4 downto 0);
begin
    process(A, B, Add_Sub)
    begin
        if Add_Sub = '0' then
            temp <= std_logic_vector(
                        unsigned('0' & A) + unsigned('0' & B));
        else
            temp <= std_logic_vector(
                        unsigned('0' & A) - unsigned('0' & B));
        end if;
    end process;

    Result   <= temp(3 downto 0);
    Overflow <= temp(4);
    Zero     <= '1' when temp(3 downto 0) = "0000" else '0';
end Behavioral;
