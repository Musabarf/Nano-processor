----------------------------------------------------------------------------------
-- Module Name: Display_Controller - Behavioral
-- Description: 4-digit time-multiplexed 7-segment display controller.
--              Refreshes all 4 digits at ~1 kHz each (4 kHz total scan).
--
--   Digit layout on Basys3 (left to right):
--   ┌─────────┬─────────┬─────────┬─────────┐
--   │ Digit 3 │ Digit 2 │ Digit 1 │ Digit 0 │
--   │  PC[2:0]│  GT/LT  │OVF/ZERO │ Result  │
--   └─────────┴─────────┴─────────┴─────────┘
--   an[3]     an[2]     an[1]     an[0]
--
--   Digit 0 (an[0]) : Result[3:0]          hex digit  e.g. "E" for 14
--   Digit 1 (an[1]) : flags OVF/Zero       shows "0F" style
--                     upper nibble: {0,0,0,Overflow}
--                     lower nibble: {0,0,0,Zero}      -- but we encode as hex
--                     Actually encoded as: {2'b0, Overflow, Zero} -> 0..3
--   Digit 2 (an[2]) : comparator flags     {2'b0, GT, LT} -> 0..3
--   Digit 3 (an[3]) : PC address[2:0]      0..7
--
--   Refresh: with 100 MHz clock, divide by 25000 -> 4 kHz scan rate
--            -> each digit gets ~1 ms on time  (flicker-free)
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Display_Controller is
    Port ( Clk      : in  STD_LOGIC;
           Reset    : in  STD_LOGIC;
           -- Data inputs
           Result   : in  STD_LOGIC_VECTOR(3 downto 0);   -- digit 0
           Overflow : in  STD_LOGIC;                       -- digit 1 bit1
           Zero     : in  STD_LOGIC;                       -- digit 1 bit0
           GT       : in  STD_LOGIC;                       -- digit 2 bit1
           LT       : in  STD_LOGIC;                       -- digit 2 bit0
           PC       : in  STD_LOGIC_VECTOR(2 downto 0);   -- digit 3
           -- 7-segment outputs (active low)
           seg      : out STD_LOGIC_VECTOR(6 downto 0);
           an       : out STD_LOGIC_VECTOR(3 downto 0));
end Display_Controller;

architecture Behavioral of Display_Controller is

    -- Refresh counter: 100 MHz / 25000 = 4000 Hz scan rate
    constant REFRESH_MAX : integer := 24999;
    signal refresh_cnt   : integer range 0 to REFRESH_MAX := 0;
    signal digit_sel     : STD_LOGIC_VECTOR(1 downto 0) := "00";

    -- Active digit data
    signal active_hex    : STD_LOGIC_VECTOR(3 downto 0);

    -- Decoder
    component Hex_to_7seg
        Port ( hex_in : in  STD_LOGIC_VECTOR(3 downto 0);
               seg    : out STD_LOGIC_VECTOR(6 downto 0));
    end component;

begin

    -- ---------------------------------------------------------------
    -- Refresh counter & digit selector
    -- ---------------------------------------------------------------
    process(Clk, Reset)
    begin
        if Reset = '1' then
            refresh_cnt <= 0;
            digit_sel   <= "00";
        elsif rising_edge(Clk) then
            if refresh_cnt = REFRESH_MAX then
                refresh_cnt <= 0;
                digit_sel   <= std_logic_vector(unsigned(digit_sel) + 1);
            else
                refresh_cnt <= refresh_cnt + 1;
            end if;
        end if;
    end process;

    -- ---------------------------------------------------------------
    -- Select which digit's data to display & drive anode
    -- ---------------------------------------------------------------
    process(digit_sel, Result, Overflow, Zero, GT, LT, PC)
    begin
        case digit_sel is
            when "00" =>  -- Digit 0: Result (hex)
                active_hex <= Result;
                an         <= "1110";   -- an[0] active (low)

            when "01" =>  -- Digit 1: OVF & Zero flags
                -- Encode as: bit1=Overflow, bit0=Zero -> shows 0,1,2,3
                active_hex <= "00" & Overflow & Zero;
                an         <= "1101";   -- an[1] active

            when "10" =>  -- Digit 2: GT & LT flags
                -- Encode as: bit1=GT, bit0=LT -> shows 0,1,2,3
                active_hex <= "00" & GT & LT;
                an         <= "1011";   -- an[2] active

            when others =>  -- Digit 3: PC address (0-7)
                active_hex <= '0' & PC;
                an         <= "0111";   -- an[3] active
        end case;
    end process;

    -- ---------------------------------------------------------------
    -- Hex decoder
    -- ---------------------------------------------------------------
    DECODER: Hex_to_7seg
        port map (hex_in => active_hex, seg => seg);

end Behavioral;
