----------------------------------------------------------------------------------
-- Module Name: Comparator - Behavioral
-- Description: 4-bit unsigned comparator.
--              Compares A and B and asserts GT, LT, or Zero flags.
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Comparator is
    Port ( A    : in  STD_LOGIC_VECTOR(3 downto 0);
           B    : in  STD_LOGIC_VECTOR(3 downto 0);
           GT   : out STD_LOGIC;   -- A > B
           LT   : out STD_LOGIC;   -- A < B
           EQ   : out STD_LOGIC);  -- A = B
end Comparator;

architecture Behavioral of Comparator is
begin
    process(A, B)
    begin
        if unsigned(A) > unsigned(B) then
            GT <= '1'; LT <= '0'; EQ <= '0';
        elsif unsigned(A) < unsigned(B) then
            GT <= '0'; LT <= '1'; EQ <= '0';
        else
            GT <= '0'; LT <= '0'; EQ <= '1';
        end if;
    end process;
end Behavioral;
