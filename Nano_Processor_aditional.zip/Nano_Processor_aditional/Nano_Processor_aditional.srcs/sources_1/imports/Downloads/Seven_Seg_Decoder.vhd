library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- ============================================================
-- Seven_Seg_Decoder
-- Converts 4-bit binary value to 7-segment display encoding
-- Active LOW cathodes (Basys3 standard)
-- seg(6 downto 0) = gfedcba
--   seg(0)=a (top), seg(1)=b (top-right), seg(2)=c (bot-right)
--   seg(3)=d (bot),  seg(4)=e (bot-left),  seg(5)=f (top-left)
--   seg(6)=g (middle)
-- Displays 0–9 as decimal, A–F as hex
-- ============================================================
entity Seven_Seg_Decoder is
    Port ( num : in  STD_LOGIC_VECTOR(3 downto 0);
           seg : out STD_LOGIC_VECTOR(6 downto 0)); -- seg(6)=g ... seg(0)=a
end Seven_Seg_Decoder;

architecture Behavioral of Seven_Seg_Decoder is
begin
    process(num)
    begin
        case num is
            when "0000" => seg <= "1000000"; -- 0
            when "0001" => seg <= "1111001"; -- 1
            when "0010" => seg <= "0100100"; -- 2
            when "0011" => seg <= "0110000"; -- 3
            when "0100" => seg <= "0011001"; -- 4
            when "0101" => seg <= "0010010"; -- 5
            when "0110" => seg <= "0000010"; -- 6
            when "0111" => seg <= "1111000"; -- 7
            when "1000" => seg <= "0000000"; -- 8
            when "1001" => seg <= "0010000"; -- 9
            when others => seg <= "1111111"; -- blank
        end case;
    end process;
end Behavioral;


