library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Slow_Clock is
    Port ( Clk_100MHz : in  STD_LOGIC;
           Reset      : in  STD_LOGIC;
           Clk_slow   : out STD_LOGIC);
end Slow_Clock;

architecture Behavioral of Slow_Clock is
    -- 50_000_000 counts at 100MHz = 0.5s half-period = 1 Hz clock
    -- Change to 25_000_000 for 2 Hz (faster, easier to debug)
    constant MAX_COUNT : integer := 5;
    signal   counter   : integer range 0 to 5 := 0;
    signal   clk_reg   : STD_LOGIC := '0';
begin
    process(Clk_100MHz, Reset)
    begin
        if Reset = '1' then
            counter <= 0;
            clk_reg <= '0';
        elsif rising_edge(Clk_100MHz) then
            if counter = MAX_COUNT - 1 then
                counter <= 0;
                clk_reg <= not clk_reg;
            else
                counter <= counter + 1;
            end if;
        end if;
    end process;
    Clk_slow <= clk_reg;
end Behavioral;
