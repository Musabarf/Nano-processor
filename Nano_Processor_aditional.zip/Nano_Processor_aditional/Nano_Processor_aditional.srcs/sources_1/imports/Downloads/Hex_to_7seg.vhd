----------------------------------------------------------------------------------
-- Module Name: Hex_to_7seg - Behavioral
-- Description: Converts a 4-bit hex value to 7-segment display segments.
--              Segments are ACTIVE LOW (standard on Basys3).
--
--   Segment mapping:
--        aaa
--       f   b
--       f   b
--        ggg
--       e   c
--       e   c
--        ddd   (dp not used)
--
--   seg = {g, f, e, d, c, b, a}  (seg[0]=a ... seg[6]=g)
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Hex_to_7seg is
    Port ( hex_in : in  STD_LOGIC_VECTOR(3 downto 0);
           seg    : out STD_LOGIC_VECTOR(6 downto 0));  -- active low: {g,f,e,d,c,b,a}
end Hex_to_7seg;

architecture Behavioral of Hex_to_7seg is
begin
    process(hex_in)
    begin
        case hex_in is
            --                    gfedcba
            when "0000" => seg <= "1000000"; -- 0
            when "0001" => seg <= "1111001"; -- 1
            when "0010" => seg <= "0100100"; -- 2
            when "0011" => seg <= "0110000"; -- 3
            when "0100" => seg <= "0011001"; -- 4
            when "0101" => seg <= "0010010"; -- 5
            when "0110" => seg <= "0000010"; -- 6
            when "0111" => seg <= "1111000"; -- 7
            when "1000" => seg <= "0000000"; -- 8
            when "1001" => seg <= "0010000"; -- 9
            when "1010" => seg <= "0001000"; -- A
            when "1011" => seg <= "0000011"; -- b
            when "1100" => seg <= "1000110"; -- C
            when "1101" => seg <= "0100001"; -- d
            when "1110" => seg <= "0000110"; -- E
            when "1111" => seg <= "0001110"; -- F
            when others => seg <= "1111111"; -- all off
        end case;
    end process;
end Behavioral;
