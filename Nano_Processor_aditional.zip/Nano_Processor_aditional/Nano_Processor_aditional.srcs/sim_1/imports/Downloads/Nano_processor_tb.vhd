library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

-- ================================================================
-- Nano_processor_tb
-- Testbench for the corrected lab-spec Nano_processor
-- Program in ROM computes 1+2+3 = 6, stores result in R7
--
-- Instruction encoding (2-bit opcode):
--   MOVI R,d  : 10 RRR 000 dddd
--   ADD Ra,Rb : 00 RaRaRa RbRbRb 0000
--   NEG R     : 01 RRR 000000000
--   JZR R,d   : 11 RRR 0000 ddd
--
-- ROM program:
--   addr 0: MOVI R1, #1    R1 = 1
--   addr 1: MOVI R2, #2    R2 = 2
--   addr 2: MOVI R3, #3    R3 = 3
--   addr 3: ADD  R7, R1    R7 = 0 + 1 = 1
--   addr 4: ADD  R7, R2    R7 = 1 + 2 = 3
--   addr 5: ADD  R7, R3    R7 = 3 + 3 = 6  final answer
--   addr 6: NOP
--   addr 7: NOP
-- ================================================================

entity Nano_processor_tb is
end Nano_processor_tb;

architecture Behavioral of Nano_processor_tb is

    -- Component under test 
    component Nano_processor
        Port ( Clk      : in  STD_LOGIC;
               Reset    : in  STD_LOGIC;
               R7_out   : out STD_LOGIC_VECTOR(3 downto 0);
               Overflow : out STD_LOGIC;
               Zero     : out STD_LOGIC;
               seg      : out STD_LOGIC_VECTOR(6 downto 0);
               an       : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    -- Testbench signals
    signal Clk      : STD_LOGIC := '0';
    signal Reset    : STD_LOGIC := '1';
    signal R7_out   : STD_LOGIC_VECTOR(3 downto 0);
    signal Overflow : STD_LOGIC;
    signal Zero     : STD_LOGIC;
    signal seg      : STD_LOGIC_VECTOR(6 downto 0);
    signal an       : STD_LOGIC_VECTOR(3 downto 0);

    -- Clock period 
    -- We use a FAST clock in simulation so we don't have to wait
    -- 50 million cycles for the slow clock divider.
    -- The Slow_Clock inside Nano_processor uses MAX_COUNT=50_000_000
    -- at 100MHz. In simulation we set CLK_PERIOD = 10ns (100MHz) and
    -- the slow clock fires every 500ms of sim time that is fine for
    -- behavioural sim.  To speed things up, temporarily change
    -- MAX_COUNT in Slow_Clock.vhd to 5 before simulating (then restore).
    --
    -- SIMULATION TIP: Change Slow_Clock MAX_COUNT to 5 for fast sim:
    --   constant MAX_COUNT : integer := 5;
    -- This makes the slow clock toggle every 5 fast cycles.
    -- Restore to 50_000_000 before generating bitstream.
    -- ======================================================================================================
    constant CLK_PERIOD : time := 10 ns;  -- 100 MHz fast clock

    -- Helper: convert SLV to integer string
    function to_str(s : STD_LOGIC_VECTOR) return string is
    begin
        return integer'image(to_integer(unsigned(s)));
    end function;

    -- Helper: 4-bit SLV to binary string
    function to_bin(s : STD_LOGIC_VECTOR(3 downto 0)) return string is
        variable result : string(1 to 4);
    begin
        for i in 3 downto 0 loop
            if s(i) = '1' then
                result(4-i) := '1';
            else
                result(4-i) := '0';
            end if;
        end loop;
        return result;
    end function;

begin

    --Instantiate UUT 
    UUT: Nano_processor
        port map (
            Clk      => Clk,
            Reset    => Reset,
            R7_out   => R7_out,
            Overflow => Overflow,
            Zero     => Zero,
            seg      => seg,
            an       => an);

    --  Clock generator (100 MHz) 
    clk_proc: process
    begin
        Clk <= '0'; wait for CLK_PERIOD / 2;
        Clk <= '1'; wait for CLK_PERIOD / 2;
    end process;

    --====================================================    
    -- STIMULUS PROCESS
    -- NOTE: With Slow_Clock MAX_COUNT=5 (simulation mode),
    --       each slow clock cycle = 10 fast cycles = 100 ns.
    --       With MAX_COUNT=50_000_000 (board mode), each
    --       slow cycle = 1 second of simulation time.
    -- ========================================================
    stim_proc: process

        -- Wait for exactly N slow clock cycles
        -- Each slow clock half-period = MAX_COUNT * CLK_PERIOD
        -- For MAX_COUNT=5: slow half = 50ns, full = 100ns
        -- Adjust SLOW_CLK_PERIOD to match your MAX_COUNT setting
        constant SLOW_CLK_PERIOD : time := 100 ns;  -- for MAX_COUNT=5
        -- constant SLOW_CLK_PERIOD : time := 1000 ms; -- for MAX_COUNT=50_000_000

    begin

        -- RESET ============================================================================================
        Reset <= '1';
        report "========================================" severity note;
        report " Nano_processor Testbench START" severity note;
        report " Program: compute 1+2+3 = 6 in R7" severity note;
        report "========================================" severity note;
        wait for CLK_PERIOD * 4;
        Reset <= '0';
        wait for CLK_PERIOD * 2;
        report "[RESET released] Processor starting..." severity note;

        --  CYCLE 1: MOVI R1, #1 
        -- Instruction: 10 001 000 0001 = "100010000001"
        -- R1 <= 1
        wait for SLOW_CLK_PERIOD;
        report "-------------------------------------------" severity note;
        report "[Cycle 1] MOVI R1, #1" severity note;
        report "  R7_out   = " & to_bin(R7_out) & " (" & to_str(R7_out) & ")" severity note;
        report "  Overflow = " & STD_LOGIC'image(Overflow) severity note;
        report "  Zero     = " & STD_LOGIC'image(Zero) severity note;
        -- R7 still 0 at this point (nothing written to R7 yet)
        assert R7_out = "0000"
            report "[FAIL] Cycle 1: R7 should still be 0, got " & to_str(R7_out)
            severity error;

        -- CYCLE 2: MOVI R2, #2 
        -- Instruction: 10 010 000 0010 = "100100000010"
        -- R2 <= 2
        wait for SLOW_CLK_PERIOD;
        report "-------------------------------------------" severity note;
        report "[Cycle 2] MOVI R2, #2" severity note;
        report "  R7_out   = " & to_bin(R7_out) & " (" & to_str(R7_out) & ")" severity note;
        assert R7_out = "0000"
            report "[FAIL] Cycle 2: R7 should still be 0, got " & to_str(R7_out)
            severity error;

        -- CYCLE 3: MOVI R3, #3 
        -- Instruction: 10 011 000 0011 = "100110000011"
        -- R3 <= 3
        wait for SLOW_CLK_PERIOD;
        report "-------------------------------------------" severity note;
        report "[Cycle 3] MOVI R3, #3" severity note;
        report "  R7_out   = " & to_bin(R7_out) & " (" & to_str(R7_out) & ")" severity note;
        assert R7_out = "0000"
            report "[FAIL] Cycle 3: R7 should still be 0, got " & to_str(R7_out)
            severity error;

        -- CYCLE 4: ADD R7, R1 
        -- Instruction: 00 111 001 0000 = "001110010000"
        -- R7 = R7 + R1 = 0 + 1 = 1
        wait for SLOW_CLK_PERIOD;
        report "-------------------------------------------" severity note;
        report "[Cycle 4] ADD R7, R1  R7 = 0 + 1 = 1" severity note;
        report "  R7_out   = " & to_bin(R7_out) & " (" & to_str(R7_out) & ")" severity note;
        report "  Overflow = " & STD_LOGIC'image(Overflow) severity note;
        report "  Zero     = " & STD_LOGIC'image(Zero) severity note;
        assert R7_out = "0001"
            report "[FAIL] Cycle 4: ADD R7,R1 expected 1 (0001), got " & to_str(R7_out)
            severity error;
        assert Overflow = '0'
            report "[FAIL] Cycle 4: Overflow should be 0" severity error;
        assert Zero = '0'
            report "[FAIL] Cycle 4: Zero should be 0 (result=1)" severity error;

        -- CYCLE 5: ADD R7, R2 
        -- Instruction: 00 111 010 0000 = "001110100000"
        -- R7 = R7 + R2 = 1 + 2 = 3
        wait for SLOW_CLK_PERIOD;
        report "-------------------------------------------" severity note;
        report "[Cycle 5] ADD R7, R2  R7 = 1 + 2 = 3" severity note;
        report "  R7_out   = " & to_bin(R7_out) & " (" & to_str(R7_out) & ")" severity note;
        report "  Overflow = " & STD_LOGIC'image(Overflow) severity note;
        report "  Zero     = " & STD_LOGIC'image(Zero) severity note;
        assert R7_out = "0011"
            report "[FAIL] Cycle 5: ADD R7,R2 expected 3 (0011), got " & to_str(R7_out)
            severity error;
        assert Overflow = '0'
            report "[FAIL] Cycle 5: Overflow should be 0" severity error;

        -- CYCLE 6: ADD R7, R3 
        -- Instruction: 00 111 011 0000 = "001110110000"
        -- R7 = R7 + R3 = 3 + 3 = 6 = "0110"  �? FINAL ANSWER
        wait for SLOW_CLK_PERIOD;
        report "-------------------------------------------" severity note;
        report "[Cycle 6] ADD R7, R3   R7 = 3 + 3 = 6  *** FINAL RESULT ***" severity note;
        report "  R7_out   = " & to_bin(R7_out) & " (" & to_str(R7_out) & ")" severity note;
        report "  Overflow = " & STD_LOGIC'image(Overflow) severity note;
        report "  Zero     = " & STD_LOGIC'image(Zero) severity note;
        assert R7_out = "0110"
            report "[FAIL] Cycle 6: ADD R7,R3 expected 6 (0110), got " & to_str(R7_out)
            severity error;
        assert Overflow = '0'
            report "[FAIL] Cycle 6: Overflow should be 0 (6 fits in 4 bits)" severity error;
        assert Zero = '0'
            report "[FAIL] Cycle 6: Zero should be 0 (result=6)" severity error;
        report "  7-seg = " & STD_LOGIC'image(seg(6)) &
                              STD_LOGIC'image(seg(5)) &
                              STD_LOGIC'image(seg(4)) &
                              STD_LOGIC'image(seg(3)) &
                              STD_LOGIC'image(seg(2)) &
                              STD_LOGIC'image(seg(1)) &
                              STD_LOGIC'image(seg(0)) &
               " (expect 0000010 = digit 6)" severity note;
        assert seg = "0000010"
            report "[FAIL] Cycle 6: 7-seg expected '6' (0000010), got different"
            severity error;

        -- CYCLE 7: NOP 
        wait for SLOW_CLK_PERIOD;
        report "-------------------------------------------" severity note;
        report "[Cycle 7] NOP   R7 unchanged = 6" severity note;
        report "  R7_out   = " & to_bin(R7_out) & " (" & to_str(R7_out) & ")" severity note;
        assert R7_out = "0110"
            report "[FAIL] Cycle 7: NOP should leave R7=6 (0110), got " & to_str(R7_out)
            severity error;

        --  CYCLE 8: NOP 
        wait for SLOW_CLK_PERIOD;
        report "[Cycle 8] NOP   R7 unchanged = 6" severity note;
        assert R7_out = "0110"
            report "[FAIL] Cycle 8: NOP should leave R7=6 (0110), got " & to_str(R7_out)
            severity error;

        -- TEST RESET 
        report "-------------------------------------------" severity note;
        report "[TEST] Applying Reset mid-execution..." severity note;
        Reset <= '1';
        wait for SLOW_CLK_PERIOD;
        report "  R7_out after Reset = " & to_bin(R7_out) & " (" & to_str(R7_out) & ")" severity note;
        assert R7_out = "0000"
            report "[FAIL] Reset: R7 should be 0000 after reset, got " & to_str(R7_out)
            severity error;

        -- RE-RUN after Reset 
        report "-------------------------------------------" severity note;
        report "[TEST] Releasing Reset  processor re-executes..." severity note;
        Reset <= '0';
        wait for SLOW_CLK_PERIOD * 7;  -- wait through all 6 active instructions + 1

        report "-------------------------------------------" severity note;
        report "[TEST] After full re-run: checking R7 = 6" severity note;
        report "  R7_out   = " & to_bin(R7_out) & " (" & to_str(R7_out) & ")" severity note;
        assert R7_out = "0110"
            report "[FAIL] Re-run: R7 expected 6 (0110) after second run, got " & to_str(R7_out)
            severity error;

        -- SUMMARY 
        report "========================================" severity note;
        report " Nano_processor Testbench COMPLETE" severity note;
        report " Expected: R7 = 6 (0110) = 1+2+3" severity note;
        report " Got:      R7 = " & to_bin(R7_out) & " (" & to_str(R7_out) & ")" severity note;
        report "========================================" severity note;

        wait; -- stop simulation
    end process;

    -- 
    -- MONITOR PROCESS
    -- Prints R7, Overflow, Zero on every slow clock rising edge
    -- (monitors the slow clock signal indirectly via periodic check)
    -- 
    monitor_proc: process(Clk)
        variable cycle_cnt : integer := 0;
    begin
        if rising_edge(Clk) and Reset = '0' then
            cycle_cnt := cycle_cnt + 1;
            -- Print every 10 fast clock cycles (adjust for your MAX_COUNT)
            if cycle_cnt mod 10 = 0 then
                report "FAST_CLK#" & integer'image(cycle_cnt) &
                       " | R7=" & to_bin(R7_out) &
                       " OVF=" & STD_LOGIC'image(Overflow) &
                       " Z=" & STD_LOGIC'image(Zero)
                       severity note;
            end if;
        end if;
    end process;

end Behavioral;
