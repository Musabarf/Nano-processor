library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Comparator is
end TB_Comparator;

architecture Behavioral of TB_Comparator is

    component Comparator
        Port (
            A    : in  STD_LOGIC_VECTOR(3 downto 0);
            B    : in  STD_LOGIC_VECTOR(3 downto 0);
            EQ   : out STD_LOGIC;
            GT   : out STD_LOGIC;
            LT   : out STD_LOGIC
        );
    end component;

    signal A, B : STD_LOGIC_VECTOR(3 downto 0);
    signal EQ, GT, LT : STD_LOGIC;

begin

    UUT: Comparator
        port map (A => A, B => B, EQ => EQ, GT => GT, LT => LT);

    process
    begin
        -- A = B
        A <= "0101"; B <= "0101"; wait for 20 ns;
        assert EQ = '1' and GT = '0' and LT = '0'
            report "FAIL: A=B=5" severity error;

        -- A > B
        A <= "1001"; B <= "0011"; wait for 20 ns;
        assert EQ = '0' and GT = '1' and LT = '0'
            report "FAIL: A>B (9>3)" severity error;

        -- A < B
        A <= "0010"; B <= "1110"; wait for 20 ns;
        assert EQ = '0' and GT = '0' and LT = '1'
            report "FAIL: A<B (2<14)" severity error;

        -- A = 0, B = 0
        A <= "0000"; B <= "0000"; wait for 20 ns;
        assert EQ = '1' and GT = '0' and LT = '0'
            report "FAIL: A=B=0" severity error;

        -- A = 15, B = 0
        A <= "1111"; B <= "0000"; wait for 20 ns;
        assert GT = '1' report "FAIL: A=15 > B=0" severity error;

        -- A = 0, B = 15
        A <= "0000"; B <= "1111"; wait for 20 ns;
        assert LT = '1' report "FAIL: A=0 < B=15" severity error;

        report "TB_Comparator: All tests passed." severity note;
        wait;
    end process;

end Behavioral;
