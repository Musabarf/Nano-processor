library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Mux_8_4bit_new is
end TB_Mux_8_4bit_new;

architecture Behavioral of TB_Mux_8_4bit_new is

    component Mux_8_4bit_new
        Port (
            I0, I1, I2, I3 : in  STD_LOGIC_VECTOR(3 downto 0);
            I4, I5, I6, I7 : in  STD_LOGIC_VECTOR(3 downto 0);
            Sel             : in  STD_LOGIC_VECTOR(2 downto 0);
            Y               : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    signal I0, I1, I2, I3 : STD_LOGIC_VECTOR(3 downto 0);
    signal I4, I5, I6, I7 : STD_LOGIC_VECTOR(3 downto 0);
    signal Sel             : STD_LOGIC_VECTOR(2 downto 0);
    signal Y               : STD_LOGIC_VECTOR(3 downto 0);

begin

    UUT: Mux_8_4bit_new
        port map (
            I0 => I0, I1 => I1, I2 => I2, I3 => I3,
            I4 => I4, I5 => I5, I6 => I6, I7 => I7,
            Sel => Sel, Y => Y
        );

    process
    begin
        -- Distinct values for each channel
        I0 <= "1000"; I1 <= "1001"; I2 <= "1010"; I3 <= "1011";
        I4 <= "1100"; I5 <= "1101"; I6 <= "1110"; I7 <= "1111";

        Sel <= "000"; wait for 20 ns;
        assert Y = "1000" report "FAIL: Sel=000" severity error;

        Sel <= "001"; wait for 20 ns;
        assert Y = "1001" report "FAIL: Sel=001" severity error;

        Sel <= "010"; wait for 20 ns;
        assert Y = "1010" report "FAIL: Sel=010" severity error;

        Sel <= "011"; wait for 20 ns;
        assert Y = "1011" report "FAIL: Sel=011" severity error;

        Sel <= "100"; wait for 20 ns;
        assert Y = "1100" report "FAIL: Sel=100" severity error;

        Sel <= "101"; wait for 20 ns;
        assert Y = "1101" report "FAIL: Sel=101" severity error;

        Sel <= "110"; wait for 20 ns;
        assert Y = "1110" report "FAIL: Sel=110" severity error;

        Sel <= "111"; wait for 20 ns;
        assert Y = "1111" report "FAIL: Sel=111" severity error;

        report "TB_Mux_8_4bit_new: All tests passed." severity note;
        wait;
    end process;

end Behavioral;
