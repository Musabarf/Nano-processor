library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Reg_4bit is
end TB_Reg_4bit;

architecture Behavioral of TB_Reg_4bit is

    component Reg_4bit
        Port (
            Clk     : in  STD_LOGIC;
            Reset   : in  STD_LOGIC;
            Load    : in  STD_LOGIC;
            D       : in  STD_LOGIC_VECTOR(3 downto 0);
            Q       : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    signal Clk   : STD_LOGIC := '0';
    signal Reset : STD_LOGIC := '0';
    signal Load  : STD_LOGIC := '0';
    signal D     : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal Q     : STD_LOGIC_VECTOR(3 downto 0);

    constant CLK_PERIOD : time := 20 ns;

begin

    Clk <= not Clk after CLK_PERIOD / 2;

    UUT: Reg_4bit
        port map (Clk => Clk, Reset => Reset, Load => Load, D => D, Q => Q);

    process
    begin
        -- Reset register
        Reset <= '1'; wait for CLK_PERIOD;
        Reset <= '0';
        assert Q = "0000" report "FAIL: After reset Q should be 0000" severity error;

        -- Load with no enable (Q should stay 0000)
        D <= "1010"; Load <= '0'; wait for CLK_PERIOD;
        assert Q = "0000" report "FAIL: No load, Q changed unexpectedly" severity error;

        -- Load 1010
        Load <= '1'; wait for CLK_PERIOD;
        Load <= '0';
        assert Q = "1010" report "FAIL: Load 1010 failed" severity error;

        -- Load 0101
        D <= "0101"; Load <= '1'; wait for CLK_PERIOD;
        Load <= '0';
        assert Q = "0101" report "FAIL: Load 0101 failed" severity error;

        -- Load 1111
        D <= "1111"; Load <= '1'; wait for CLK_PERIOD;
        Load <= '0';
        assert Q = "1111" report "FAIL: Load 1111 failed" severity error;

        -- Reset clears
        Reset <= '1'; wait for CLK_PERIOD;
        Reset <= '0';
        assert Q = "0000" report "FAIL: Reset after load" severity error;

        report "TB_Reg_4bit: All tests passed." severity note;
        wait;
    end process;

end Behavioral;
