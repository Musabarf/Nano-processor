library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_ROM is
end TB_ROM;

architecture Behavioral of TB_ROM is

    component ROM
        Port (
            Address : in  STD_LOGIC_VECTOR(2 downto 0);
            Data    : out STD_LOGIC_VECTOR(11 downto 0)
        );
    end component;

    signal Address : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal Data    : STD_LOGIC_VECTOR(11 downto 0);

begin

    UUT: ROM
        port map (Address => Address, Data => Data);

    process
    begin
        -- Read all 8 addresses and display output
        Address <= "000"; wait for 20 ns;
        report "ROM[0] = " & integer'image(to_integer(unsigned(Data)));

        Address <= "001"; wait for 20 ns;
        report "ROM[1] = " & integer'image(to_integer(unsigned(Data)));

        Address <= "010"; wait for 20 ns;
        report "ROM[2] = " & integer'image(to_integer(unsigned(Data)));

        Address <= "011"; wait for 20 ns;
        report "ROM[3] = " & integer'image(to_integer(unsigned(Data)));

        Address <= "100"; wait for 20 ns;
        report "ROM[4] = " & integer'image(to_integer(unsigned(Data)));

        Address <= "101"; wait for 20 ns;
        report "ROM[5] = " & integer'image(to_integer(unsigned(Data)));

        Address <= "110"; wait for 20 ns;
        report "ROM[6] = " & integer'image(to_integer(unsigned(Data)));

        Address <= "111"; wait for 20 ns;
        report "ROM[7] = " & integer'image(to_integer(unsigned(Data)));

        report "TB_ROM: All addresses read." severity note;
        wait;
    end process;

end Behavioral;
