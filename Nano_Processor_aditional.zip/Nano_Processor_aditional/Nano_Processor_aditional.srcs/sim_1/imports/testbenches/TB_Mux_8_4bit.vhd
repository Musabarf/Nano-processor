library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Mux_8_4bit is
end TB_Mux_8_4bit;

architecture Behavioral of TB_Mux_8_4bit is

    component Mux_8_4bit
        Port (
            I0, I1, I2, I3 : in  STD_LOGIC_VECTOR(3 downto 0);
            I4, I5, I6, I7 : in  STD_LOGIC_VECTOR(3 downto 0);
            Sel             : in  STD_LOGIC_VECTOR(2 downto 0);
            Y               : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    signal I0, I1, I2, I3 : STD_LOGIC_VECTOR(3 downto 0);
    signal I4, I5, I6, I7 : STD_LOGIC_VECTOR(3 downto 0);
    signal Sel             : STD_LOGIC_VECTOR(2 downto 0);
    signal Y               : STD_LOGIC_VECTOR(3 downto 0);

begin

    UUT: Mux_8_4bit
        port map (
            I0 => I0, I1 => I1, I2 => I2, I3 => I3,
            I4 => I4, I5 => I5, I6 => I6, I7 => I7,
            Sel => Sel, Y => Y
        );

    process
    begin
        I0 <= "0000"; I1 <= "0001"; I2 <= "0010"; I3 <= "0011";
        I4 <= "0100"; I5 <= "0101"; I6 <= "0110"; I7 <= "0111";

        Sel <= "000"; wait for 20 ns;
        assert Y = "0000" report "FAIL: Sel=000" severity error;

        Sel <= "001"; wait for 20 ns;
        assert Y = "0001" report "FAIL: Sel=001" severity error;

        Sel <= "010"; wait for 20 ns;
        assert Y = "0010" report "FAIL: Sel=010" severity error;

        Sel <= "011"; wait for 20 ns;
        assert Y = "0011" report "FAIL: Sel=011" severity error;

        Sel <= "100"; wait for 20 ns;
        assert Y = "0100" report "FAIL: Sel=100" severity error;

        Sel <= "101"; wait for 20 ns;
        assert Y = "0101" report "FAIL: Sel=101" severity error;

        Sel <= "110"; wait for 20 ns;
        assert Y = "0110" report "FAIL: Sel=110" severity error;

        Sel <= "111"; wait for 20 ns;
        assert Y = "0111" report "FAIL: Sel=111" severity error;

        report "TB_Mux_8_4bit: All tests passed." severity note;
        wait;
    end process;

end Behavioral;
