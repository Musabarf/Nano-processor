library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity TB_Program_Counter is
end TB_Program_Counter;

architecture Behavioral of TB_Program_Counter is

    component Program_Counter
        Port (
            Clk      : in  STD_LOGIC;
            Reset    : in  STD_LOGIC;
            Jump     : in  STD_LOGIC;
            Jump_Addr: in  STD_LOGIC_VECTOR(2 downto 0);
            PC_out   : out STD_LOGIC_VECTOR(2 downto 0)
        );
    end component;

    signal Clk       : STD_LOGIC := '0';
    signal Reset     : STD_LOGIC := '0';
    signal Jump      : STD_LOGIC := '0';
    signal Jump_Addr : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal PC_out    : STD_LOGIC_VECTOR(2 downto 0);

    constant CLK_PERIOD : time := 20 ns;

begin

    Clk <= not Clk after CLK_PERIOD / 2;

    UUT: Program_Counter
        port map (
            Clk       => Clk,
            Reset     => Reset,
            Jump      => Jump,
            Jump_Addr => Jump_Addr,
            PC_out    => PC_out
        );

    process
    begin
        -- Apply Reset
        Reset <= '1'; wait for CLK_PERIOD;
        Reset <= '0';

        -- Let PC increment naturally for 5 cycles
        wait for CLK_PERIOD;
        assert PC_out = "001" report "FAIL: PC after 1 cycle" severity error;

        wait for CLK_PERIOD;
        assert PC_out = "010" report "FAIL: PC after 2 cycles" severity error;

        wait for CLK_PERIOD;
        assert PC_out = "011" report "FAIL: PC after 3 cycles" severity error;

        -- Test Jump: jump to address 6
        Jump <= '1'; Jump_Addr <= "110"; wait for CLK_PERIOD;
        Jump <= '0';
        assert PC_out = "110" report "FAIL: PC after jump to 6" severity error;

        -- Continue incrementing after jump
        wait for CLK_PERIOD;
        assert PC_out = "111" report "FAIL: PC after jump +1" severity error;

        -- Test Reset again mid-run
        Reset <= '1'; wait for CLK_PERIOD;
        Reset <= '0';
        assert PC_out = "000" report "FAIL: PC after mid-run reset" severity error;

        report "TB_Program_Counter: All tests done." severity note;
        wait;
    end process;

end Behavioral;
