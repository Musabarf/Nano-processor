library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity TB_Add_Sub_unit is
end TB_Add_Sub_unit;

architecture Behavioral of TB_Add_Sub_unit is

    component Add_Sub_unit
        Port (
            A      : in  STD_LOGIC_VECTOR(3 downto 0);
            B      : in  STD_LOGIC_VECTOR(3 downto 0);
            Mode   : in  STD_LOGIC;   -- '0' = Add, '1' = Subtract
            Result : out STD_LOGIC_VECTOR(3 downto 0);
            Cout   : out STD_LOGIC;
            Zero   : out STD_LOGIC
        );
    end component;

    signal A, B, Result : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal Mode         : STD_LOGIC := '0';
    signal Cout, Zero   : STD_LOGIC;

begin

    UUT: Add_Sub_unit
        port map (A => A, B => B, Mode => Mode, Result => Result, Cout => Cout, Zero => Zero);

    process
    begin
        -- Addition tests (Mode = 0)
        Mode <= '0';

        -- 3 + 4 = 7
        A <= "0011"; B <= "0100"; wait for 20 ns;
        assert Result = "0111" report "FAIL: ADD 3+4" severity error;
        assert Zero = '0'      report "FAIL: Zero flag 3+4" severity error;

        -- 0 + 0 = 0 (Zero flag)
        A <= "0000"; B <= "0000"; wait for 20 ns;
        assert Result = "0000" report "FAIL: ADD 0+0" severity error;
        assert Zero = '1'      report "FAIL: Zero flag 0+0" severity error;

        -- 8 + 8 = 16 (carry)
        A <= "1000"; B <= "1000"; wait for 20 ns;
        assert Cout = '1' report "FAIL: Carry on 8+8" severity error;

        -- Subtraction tests (Mode = 1)
        Mode <= '1';

        -- 7 - 3 = 4
        A <= "0111"; B <= "0011"; wait for 20 ns;
        assert Result = "0100" report "FAIL: SUB 7-3" severity error;
        assert Zero = '0'      report "FAIL: Zero flag 7-3" severity error;

        -- 5 - 5 = 0 (Zero flag)
        A <= "0101"; B <= "0101"; wait for 20 ns;
        assert Result = "0000" report "FAIL: SUB 5-5" severity error;
        assert Zero = '1'      report "FAIL: Zero flag 5-5" severity error;

        -- 2 - 6 = -4 (borrow/underflow)
        A <= "0010"; B <= "0110"; wait for 20 ns;
        assert Result = "1100" report "FAIL: SUB 2-6 underflow" severity error;

        report "TB_Add_Sub_unit: All tests done." severity note;
        wait;
    end process;

end Behavioral;
