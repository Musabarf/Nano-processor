library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Tri_State_buffer_4bit is
end TB_Tri_State_buffer_4bit;

architecture Behavioral of TB_Tri_State_buffer_4bit is

    component Tri_State_buffer_4bit
        Port (
            En : in  STD_LOGIC;
            A  : in  STD_LOGIC_VECTOR(3 downto 0);
            Y  : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    signal En : STD_LOGIC := '0';
    signal A  : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal Y  : STD_LOGIC_VECTOR(3 downto 0);

begin

    UUT: Tri_State_buffer_4bit
        port map (En => En, A => A, Y => Y);

    process
    begin
        -- Disabled: all bits high-Z
        En <= '0'; A <= "1010"; wait for 20 ns;
        assert Y = "ZZZZ" report "FAIL: En=0 -> Y should be ZZZZ" severity error;

        -- Enabled: output matches input
        En <= '1'; A <= "1010"; wait for 20 ns;
        assert Y = "1010" report "FAIL: En=1, A=1010" severity error;

        A <= "0101"; wait for 20 ns;
        assert Y = "0101" report "FAIL: En=1, A=0101" severity error;

        A <= "1111"; wait for 20 ns;
        assert Y = "1111" report "FAIL: En=1, A=1111" severity error;

        A <= "0000"; wait for 20 ns;
        assert Y = "0000" report "FAIL: En=1, A=0000" severity error;

        -- Disable
        En <= '0'; wait for 20 ns;
        assert Y = "ZZZZ" report "FAIL: Re-disable -> ZZZZ" severity error;

        report "TB_Tri_State_buffer_4bit: All tests passed." severity note;
        wait;
    end process;

end Behavioral;
