library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Mux_2_3bit is
end TB_Mux_2_3bit;

architecture Behavioral of TB_Mux_2_3bit is

    component Mux_2_3bit
        Port (
            I0  : in  STD_LOGIC_VECTOR(2 downto 0);
            I1  : in  STD_LOGIC_VECTOR(2 downto 0);
            Sel : in  STD_LOGIC;
            Y   : out STD_LOGIC_VECTOR(2 downto 0)
        );
    end component;

    signal I0, I1, Y : STD_LOGIC_VECTOR(2 downto 0);
    signal Sel        : STD_LOGIC;

begin

    UUT: Mux_2_3bit
        port map (I0 => I0, I1 => I1, Sel => Sel, Y => Y);

    process
    begin
        I0 <= "101"; I1 <= "010";

        -- Select I0
        Sel <= '0'; wait for 20 ns;
        assert Y = "101" report "FAIL: Sel=0 should output I0=101" severity error;

        -- Select I1
        Sel <= '1'; wait for 20 ns;
        assert Y = "010" report "FAIL: Sel=1 should output I1=010" severity error;

        -- Change inputs
        I0 <= "000"; I1 <= "111";
        Sel <= '0'; wait for 20 ns;
        assert Y = "000" report "FAIL: Sel=0 I0=000" severity error;

        Sel <= '1'; wait for 20 ns;
        assert Y = "111" report "FAIL: Sel=1 I1=111" severity error;

        report "TB_Mux_2_3bit: All tests passed." severity note;
        wait;
    end process;

end Behavioral;
