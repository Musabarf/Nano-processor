library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Instruction_decoder is
end TB_Instruction_decoder;

architecture Behavioral of TB_Instruction_decoder is

    component Instruction_decoder
        Port (
            Instruction : in  STD_LOGIC_VECTOR(11 downto 0);
            Reg_A_sel   : out STD_LOGIC_VECTOR(2 downto 0);
            Reg_B_sel   : out STD_LOGIC_VECTOR(2 downto 0);
            Imm         : out STD_LOGIC_VECTOR(3 downto 0);
            Load_sel    : out STD_LOGIC;
            Add_Sub     : out STD_LOGIC;
            Jump_flag   : out STD_LOGIC;
            Mux_sel     : out STD_LOGIC
        );
    end component;

    signal Instruction : STD_LOGIC_VECTOR(11 downto 0) := (others => '0');
    signal Reg_A_sel   : STD_LOGIC_VECTOR(2 downto 0);
    signal Reg_B_sel   : STD_LOGIC_VECTOR(2 downto 0);
    signal Imm         : STD_LOGIC_VECTOR(3 downto 0);
    signal Load_sel    : STD_LOGIC;
    signal Add_Sub     : STD_LOGIC;
    signal Jump_flag   : STD_LOGIC;
    signal Mux_sel     : STD_LOGIC;

begin

    UUT: Instruction_decoder
        port map (
            Instruction => Instruction,
            Reg_A_sel   => Reg_A_sel,
            Reg_B_sel   => Reg_B_sel,
            Imm         => Imm,
            Load_sel    => Load_sel,
            Add_Sub     => Add_Sub,
            Jump_flag   => Jump_flag,
            Mux_sel     => Mux_sel
        );

    process
    begin
        -- MOVI R0, 5  => opcode 100 000 0101  (Load immediate into R0 with value 5)
        Instruction <= "100000" & "0101" & "00"; wait for 20 ns;

        -- ADD R1, R2  => opcode 000 001 010 000
        Instruction <= "000" & "001" & "010" & "000"; wait for 20 ns;

        -- NEG (SUB) R3, R4
        Instruction <= "001" & "011" & "100" & "000"; wait for 20 ns;

        -- JUMP to address
        Instruction <= "010" & "000" & "0000" & "00"; wait for 20 ns;

        report "TB_Instruction_decoder: All stimulus applied." severity note;
        wait;
    end process;

end Behavioral;
