library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Hex_to_7seg is
end TB_Hex_to_7seg;

architecture Behavioral of TB_Hex_to_7seg is

    component Hex_to_7seg
        Port (
            Hex     : in  STD_LOGIC_VECTOR(3 downto 0);
            Seg_out : out STD_LOGIC_VECTOR(6 downto 0)
        );
    end component;

    signal Hex     : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal Seg_out : STD_LOGIC_VECTOR(6 downto 0);

begin

    UUT: Hex_to_7seg
        port map (Hex => Hex, Seg_out => Seg_out);

    process
    begin
        -- Test all 16 hex values and print expected segment patterns
        -- Segments: gfedcba (active low common anode assumed)
        Hex <= "0000"; wait for 20 ns; -- 0 => 1000000
        assert Seg_out = "1000000" report "FAIL: 0" severity error;

        Hex <= "0001"; wait for 20 ns; -- 1 => 1111001
        assert Seg_out = "1111001" report "FAIL: 1" severity error;

        Hex <= "0010"; wait for 20 ns; -- 2 => 0100100
        assert Seg_out = "0100100" report "FAIL: 2" severity error;

        Hex <= "0011"; wait for 20 ns; -- 3 => 0110000
        assert Seg_out = "0110000" report "FAIL: 3" severity error;

        Hex <= "0100"; wait for 20 ns; -- 4 => 0011001
        assert Seg_out = "0011001" report "FAIL: 4" severity error;

        Hex <= "0101"; wait for 20 ns; -- 5 => 0010010
        assert Seg_out = "0010010" report "FAIL: 5" severity error;

        Hex <= "0110"; wait for 20 ns; -- 6 => 0000010
        assert Seg_out = "0000010" report "FAIL: 6" severity error;

        Hex <= "0111"; wait for 20 ns; -- 7 => 1111000
        assert Seg_out = "1111000" report "FAIL: 7" severity error;

        Hex <= "1000"; wait for 20 ns; -- 8 => 0000000
        assert Seg_out = "0000000" report "FAIL: 8" severity error;

        Hex <= "1001"; wait for 20 ns; -- 9 => 0010000
        assert Seg_out = "0010000" report "FAIL: 9" severity error;

        Hex <= "1010"; wait for 20 ns; -- A => 0001000
        assert Seg_out = "0001000" report "FAIL: A" severity error;

        Hex <= "1011"; wait for 20 ns; -- B => 0000011
        assert Seg_out = "0000011" report "FAIL: B" severity error;

        Hex <= "1100"; wait for 20 ns; -- C => 1000110
        assert Seg_out = "1000110" report "FAIL: C" severity error;

        Hex <= "1101"; wait for 20 ns; -- D => 0100001
        assert Seg_out = "0100001" report "FAIL: D" severity error;

        Hex <= "1110"; wait for 20 ns; -- E => 0000110
        assert Seg_out = "0000110" report "FAIL: E" severity error;

        Hex <= "1111"; wait for 20 ns; -- F => 0001110
        assert Seg_out = "0001110" report "FAIL: F" severity error;

        report "TB_Hex_to_7seg: All tests done." severity note;
        wait;
    end process;

end Behavioral;
