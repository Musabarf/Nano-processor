library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Seven_Seg_Decoder is
end TB_Seven_Seg_Decoder;

architecture Behavioral of TB_Seven_Seg_Decoder is

    component Seven_Seg_Decoder
        Port (
            Clk       : in  STD_LOGIC;
            Digit0    : in  STD_LOGIC_VECTOR(3 downto 0);
            Digit1    : in  STD_LOGIC_VECTOR(3 downto 0);
            Anode     : out STD_LOGIC_VECTOR(1 downto 0);
            Cathode   : out STD_LOGIC_VECTOR(6 downto 0)
        );
    end component;

    signal Clk     : STD_LOGIC := '0';
    signal Digit0  : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal Digit1  : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal Anode   : STD_LOGIC_VECTOR(1 downto 0);
    signal Cathode : STD_LOGIC_VECTOR(6 downto 0);

    constant CLK_PERIOD : time := 10 ns;

begin

    Clk <= not Clk after CLK_PERIOD / 2;

    UUT: Seven_Seg_Decoder
        port map (Clk => Clk, Digit0 => Digit0, Digit1 => Digit1,
                  Anode => Anode, Cathode => Cathode);

    process
    begin
        -- Display 3 on digit0 and 7 on digit1
        Digit0 <= "0011"; Digit1 <= "0111";
        wait for 200 * CLK_PERIOD;

        -- Display A on digit0 and F on digit1
        Digit0 <= "1010"; Digit1 <= "1111";
        wait for 200 * CLK_PERIOD;

        -- Display 0 on both
        Digit0 <= "0000"; Digit1 <= "0000";
        wait for 200 * CLK_PERIOD;

        report "TB_Seven_Seg_Decoder: Simulation complete. Verify time-multiplexed Anode/Cathode in waveform." severity note;
        wait;
    end process;

end Behavioral;
