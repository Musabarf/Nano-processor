library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Registers_Bank is
end TB_Registers_Bank;

architecture Behavioral of TB_Registers_Bank is

    component Registers_Bank
        Port (
            Clk      : in  STD_LOGIC;
            Reset    : in  STD_LOGIC;
            Load_En  : in  STD_LOGIC;
            Reg_Sel  : in  STD_LOGIC_VECTOR(2 downto 0);
            D        : in  STD_LOGIC_VECTOR(3 downto 0);
            R0, R1, R2, R3, R4, R5, R6, R7 : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    signal Clk     : STD_LOGIC := '0';
    signal Reset   : STD_LOGIC := '0';
    signal Load_En : STD_LOGIC := '0';
    signal Reg_Sel : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal D       : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal R0, R1, R2, R3, R4, R5, R6, R7 : STD_LOGIC_VECTOR(3 downto 0);

    constant CLK_PERIOD : time := 20 ns;

begin

    Clk <= not Clk after CLK_PERIOD / 2;

    UUT: Registers_Bank
        port map (
            Clk => Clk, Reset => Reset, Load_En => Load_En,
            Reg_Sel => Reg_Sel, D => D,
            R0 => R0, R1 => R1, R2 => R2, R3 => R3,
            R4 => R4, R5 => R5, R6 => R6, R7 => R7
        );

    process
    begin
        -- Reset all registers
        Reset <= '1'; wait for CLK_PERIOD;
        Reset <= '0';
        assert R0 = "0000" and R1 = "0000" report "FAIL: Reset" severity error;

        -- Write 5 to R0
        Reg_Sel <= "000"; D <= "0101"; Load_En <= '1'; wait for CLK_PERIOD; Load_En <= '0';
        assert R0 = "0101" report "FAIL: R0 load" severity error;

        -- Write 9 to R1
        Reg_Sel <= "001"; D <= "1001"; Load_En <= '1'; wait for CLK_PERIOD; Load_En <= '0';
        assert R1 = "1001" report "FAIL: R1 load" severity error;

        -- Write 15 to R7
        Reg_Sel <= "111"; D <= "1111"; Load_En <= '1'; wait for CLK_PERIOD; Load_En <= '0';
        assert R7 = "1111" report "FAIL: R7 load" severity error;

        -- Confirm R0 unchanged
        assert R0 = "0101" report "FAIL: R0 changed unexpectedly" severity error;

        -- Write 0 to R3
        Reg_Sel <= "011"; D <= "0000"; Load_En <= '1'; wait for CLK_PERIOD; Load_En <= '0';
        assert R3 = "0000" report "FAIL: R3 load 0" severity error;

        report "TB_Registers_Bank: All tests done." severity note;
        wait;
    end process;

end Behavioral;
