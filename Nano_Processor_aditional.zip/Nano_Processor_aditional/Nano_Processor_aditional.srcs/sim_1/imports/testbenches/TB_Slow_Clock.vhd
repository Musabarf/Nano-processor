library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Slow_Clock is
end TB_Slow_Clock;

architecture Behavioral of TB_Slow_Clock is

    component Slow_Clock
        Port (
            Clk_in  : in  STD_LOGIC;
            Reset   : in  STD_LOGIC;
            Clk_out : out STD_LOGIC
        );
    end component;

    signal Clk_in  : STD_LOGIC := '0';
    signal Reset   : STD_LOGIC := '0';
    signal Clk_out : STD_LOGIC;

    constant CLK_PERIOD : time := 10 ns;

begin

    -- Fast system clock
    Clk_in <= not Clk_in after CLK_PERIOD / 2;

    UUT: Slow_Clock
        port map (Clk_in => Clk_in, Reset => Reset, Clk_out => Clk_out);

    process
    begin
        -- Apply reset
        Reset <= '1'; wait for 5 * CLK_PERIOD;
        Reset <= '0';

        -- Run for several hundred cycles to observe slow clock output
        wait for 2000 * CLK_PERIOD;

        report "TB_Slow_Clock: Simulation complete. Check waveform for Clk_out frequency." severity note;
        wait;
    end process;

end Behavioral;
