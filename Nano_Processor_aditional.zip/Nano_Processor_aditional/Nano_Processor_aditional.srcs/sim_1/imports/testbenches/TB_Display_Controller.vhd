library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Display_Controller is
end TB_Display_Controller;

architecture Behavioral of TB_Display_Controller is

    component Display_Controller
        Port (
            Clk       : in  STD_LOGIC;
            Reset     : in  STD_LOGIC;
            Data      : in  STD_LOGIC_VECTOR(7 downto 0);
            Anode     : out STD_LOGIC_VECTOR(3 downto 0);
            Cathode   : out STD_LOGIC_VECTOR(6 downto 0)
        );
    end component;

    signal Clk     : STD_LOGIC := '0';
    signal Reset   : STD_LOGIC := '0';
    signal Data    : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
    signal Anode   : STD_LOGIC_VECTOR(3 downto 0);
    signal Cathode : STD_LOGIC_VECTOR(6 downto 0);

    constant CLK_PERIOD : time := 10 ns;

begin

    Clk <= not Clk after CLK_PERIOD / 2;

    UUT: Display_Controller
        port map (Clk => Clk, Reset => Reset, Data => Data,
                  Anode => Anode, Cathode => Cathode);

    process
    begin
        Reset <= '1'; wait for 5 * CLK_PERIOD;
        Reset <= '0';

        -- Display 0xAB = 171
        Data <= "10101011"; wait for 500 * CLK_PERIOD;

        -- Display 0x00
        Data <= "00000000"; wait for 500 * CLK_PERIOD;

        -- Display 0xFF
        Data <= "11111111"; wait for 500 * CLK_PERIOD;

        -- Display 0x42
        Data <= "01000010"; wait for 500 * CLK_PERIOD;

        report "TB_Display_Controller: Simulation done. Verify multiplexed Anode/Cathode in waveform." severity note;
        wait;
    end process;

end Behavioral;
