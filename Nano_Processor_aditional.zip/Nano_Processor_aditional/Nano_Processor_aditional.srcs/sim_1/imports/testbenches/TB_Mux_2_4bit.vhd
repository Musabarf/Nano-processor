library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Mux_2_4bit is
end TB_Mux_2_4bit;

architecture Behavioral of TB_Mux_2_4bit is

    component Mux_2_4bit
        Port (
            I0  : in  STD_LOGIC_VECTOR(3 downto 0);
            I1  : in  STD_LOGIC_VECTOR(3 downto 0);
            Sel : in  STD_LOGIC;
            Y   : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    signal I0, I1, Y : STD_LOGIC_VECTOR(3 downto 0);
    signal Sel        : STD_LOGIC;

begin

    UUT: Mux_2_4bit
        port map (I0 => I0, I1 => I1, Sel => Sel, Y => Y);

    process
    begin
        I0 <= "1010"; I1 <= "0101";

        Sel <= '0'; wait for 20 ns;
        assert Y = "1010" report "FAIL: Sel=0 should give I0=1010" severity error;

        Sel <= '1'; wait for 20 ns;
        assert Y = "0101" report "FAIL: Sel=1 should give I1=0101" severity error;

        I0 <= "1111"; I1 <= "0000";
        Sel <= '0'; wait for 20 ns;
        assert Y = "1111" report "FAIL: I0=1111" severity error;

        Sel <= '1'; wait for 20 ns;
        assert Y = "0000" report "FAIL: I1=0000" severity error;

        report "TB_Mux_2_4bit: All tests passed." severity note;
        wait;
    end process;

end Behavioral;
