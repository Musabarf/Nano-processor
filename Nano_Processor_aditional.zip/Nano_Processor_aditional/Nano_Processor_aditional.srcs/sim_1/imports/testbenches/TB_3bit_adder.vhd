library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity TB_3bit_adder is
end TB_3bit_adder;

architecture Behavioral of TB_3bit_adder is

    component Adder_3bit
        Port (
            A   : in  STD_LOGIC_VECTOR(2 downto 0);
            B   : in  STD_LOGIC_VECTOR(2 downto 0);
            Sum : out STD_LOGIC_VECTOR(2 downto 0);
            Cout: out STD_LOGIC
        );
    end component;

    signal A    : STD_LOGIC_VECTOR(2 downto 0) := (others => '0');
    signal B    : STD_LOGIC_VECTOR(2 downto 0) := (others => '0');
    signal Sum  : STD_LOGIC_VECTOR(2 downto 0);
    signal Cout : STD_LOGIC;

begin

    UUT: Adder_3bit
        port map (A => A, B => B, Sum => Sum, Cout => Cout);

    process
    begin
        -- 0 + 0 = 0
        A <= "000"; B <= "000"; wait for 20 ns;
        assert (Sum = "000" and Cout = '0') report "FAIL: 0+0" severity error;

        -- 1 + 1 = 2
        A <= "001"; B <= "001"; wait for 20 ns;
        assert (Sum = "010" and Cout = '0') report "FAIL: 1+1" severity error;

        -- 3 + 4 = 7
        A <= "011"; B <= "100"; wait for 20 ns;
        assert (Sum = "111" and Cout = '0') report "FAIL: 3+4" severity error;

        -- 5 + 5 = 10 (carry out expected)
        A <= "101"; B <= "101"; wait for 20 ns;
        assert (Sum = "010" and Cout = '1') report "FAIL: 5+5" severity error;

        -- 7 + 7 = 14 (carry out expected)
        A <= "111"; B <= "111"; wait for 20 ns;
        assert (Sum = "110" and Cout = '1') report "FAIL: 7+7" severity error;

        -- 7 + 1 = 8 (overflow)
        A <= "111"; B <= "001"; wait for 20 ns;
        assert (Sum = "000" and Cout = '1') report "FAIL: 7+1" severity error;

        report "TB_3bit_adder: All tests done." severity note;
        wait;
    end process;

end Behavioral;
