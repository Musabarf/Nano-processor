library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Tri_State_buffer is
end TB_Tri_State_buffer;

architecture Behavioral of TB_Tri_State_buffer is

    component Tri_State_buffer
        Port (
            En : in  STD_LOGIC;
            A  : in  STD_LOGIC;
            Y  : out STD_LOGIC
        );
    end component;

    signal En : STD_LOGIC := '0';
    signal A  : STD_LOGIC := '0';
    signal Y  : STD_LOGIC;

begin

    UUT: Tri_State_buffer
        port map (En => En, A => A, Y => Y);

    process
    begin
        -- Disabled: output should be Z
        En <= '0'; A <= '0'; wait for 20 ns;
        assert Y = 'Z' report "FAIL: En=0, A=0 -> Y should be Z" severity error;

        En <= '0'; A <= '1'; wait for 20 ns;
        assert Y = 'Z' report "FAIL: En=0, A=1 -> Y should be Z" severity error;

        -- Enabled: output follows input
        En <= '1'; A <= '0'; wait for 20 ns;
        assert Y = '0' report "FAIL: En=1, A=0 -> Y should be 0" severity error;

        En <= '1'; A <= '1'; wait for 20 ns;
        assert Y = '1' report "FAIL: En=1, A=1 -> Y should be 1" severity error;

        -- Disable again
        En <= '0'; wait for 20 ns;
        assert Y = 'Z' report "FAIL: Re-disable -> Y should be Z" severity error;

        report "TB_Tri_State_buffer: All tests passed." severity note;
        wait;
    end process;

end Behavioral;
